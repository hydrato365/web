"use client";

import React, { useRef, useEffect } from "react";
import Link from "next/link";
import { 
  Share2, Eye, CheckCircle2, Volume2, Maximize, PictureInPicture,
  Play, Pause, Download, ChevronDown, ThumbsUp, Star, Bookmark, Send
} from "lucide-react";

interface ChatMessage {
  id: number;
  user: string;
  online: boolean;
  check: boolean;
  avatar: string;
  text: string;
}

interface DesktopViewProps {
  videoUrl: string;
  isPlaying: boolean;
  setIsPlaying: (val: boolean) => void;
  isDownloadOpen: boolean;
  setIsDownloadOpen: (val: boolean) => void;
  downloadProgress: string | null;
  handleDownload: (quality: string) => void;
  isLiked: boolean;
  setIsLiked: (val: boolean) => void;
  chatMessages: ChatMessage[];
  inputMessage: string;
  setInputMessage: (val: string) => void;
  handleSendMessage: (e: React.FormEvent) => void;
}

export function DesktopView({
  videoUrl,
  isPlaying,
  setIsPlaying,
  isDownloadOpen,
  setIsDownloadOpen,
  downloadProgress,
  handleDownload,
  isLiked,
  setIsLiked,
  chatMessages,
  inputMessage,
  setInputMessage,
  handleSendMessage
}: DesktopViewProps) {
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.play().catch(() => setIsPlaying(false));
      } else {
        videoRef.current.pause();
      }
    }
  }, [isPlaying, setIsPlaying]);

  const togglePiP = async () => {
    try {
      if (document.pictureInPictureElement) {
        await document.exitPictureInPicture();
      } else if (videoRef.current && document.pictureInPictureEnabled) {
        await videoRef.current.requestPictureInPicture();
      }
    } catch (error) {
      console.error("PiP failed", error);
    }
  };

  return (
    <div className="hidden md:grid pl-4 sm:pl-6 pr-3 sm:pr-4 pb-16 pt-3 w-full grid-cols-1 lg:grid-cols-12 gap-6 items-start relative z-10">
      
      {/* ============ LEFT COLUMN: VIDEO + METADATA + COMMENTS (8 Cols) - ပုံမှန် Rounded စတိုင် ============ */}
      <div className="lg:col-span-8 flex flex-col space-y-4">
        
        {/* 🎬 16:9 Video Player (Clean Rounded-2xl, No Glows) */}
        <div className="w-full aspect-[16/9] bg-black rounded-2xl border border-zinc-800 overflow-hidden relative group">
          
          {/* 🎬 တကယ့် အစစ်အမှန် Video HTML5 Element */}
          <video
            ref={videoRef}
            src={videoUrl}
            className="absolute inset-0 w-full h-full object-cover"
            playsInline
            loop
            muted
            onClick={() => setIsPlaying(!isPlaying)}
          />

          {/* Player Bottom Control Bar (Hover လုပ်မှ ပေါ်မည်) */}
          <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/90 via-black/40 to-transparent flex items-center justify-between gap-4 border-t border-white/5">
            <div className="flex items-center gap-4 w-full">
              <button 
                onClick={() => setIsPlaying(!isPlaying)}
                className="text-white hover:text-zinc-300 transition-colors cursor-pointer"
              >
                {isPlaying ? <Pause className="w-4 h-4 fill-white" /> : <Play className="w-4 h-4 fill-white" />}
              </button>

              <div className="flex-1 h-1 bg-white/20 rounded-full cursor-pointer relative flex items-center">
                <div className="h-full w-1/3 bg-[#8c1cff] rounded-full relative" />
                <div className="w-3 h-3 bg-white rounded-full absolute shadow" style={{ left: '33%' }} />
              </div>
              
              <span className="text-xs font-mono font-medium text-white px-2">17:34 / 59:32</span>

              <button className="text-white hover:text-zinc-300 transition-colors cursor-pointer"><Volume2 className="w-4 h-4" /></button>
              <button onClick={togglePiP} className="text-white hover:text-zinc-300 transition-colors cursor-pointer" title="Picture-in-Picture"><PictureInPicture className="w-4 h-4" /></button>
              <button className="text-white hover:text-zinc-300 transition-colors cursor-pointer"><Maximize className="w-4 h-4" /></button>
            </div>
          </div>
        </div>

        {/* Video Title */}
        <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white leading-snug">
          Oppenheimer Full Movie Recap - The Father of the Atomic Bomb
        </h1>

        {/* Channel Info & Action Buttons Bar */}
        <div className="flex flex-wrap items-center justify-between gap-4 pb-1">
          {/* Channel Info */}
          <div className="flex items-center gap-3">
            <Link href="/channel/minmahar" className="shrink-0 cursor-pointer">
              <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-amber-700 to-amber-900 border border-zinc-700 flex items-center justify-center font-bold text-white text-sm">
                M
              </div>
            </Link>
            <div className="flex flex-col">
              <Link href="/channel/minmahar" className="font-bold text-white hover:underline flex items-center gap-1.5 text-sm">
                Min Mahar
                <CheckCircle2 className="w-3.5 h-3.5 text-blue-500 fill-blue-500 text-[#131224]" />
              </Link>
              <span className="text-xs text-zinc-400">1.98M Tuned</span>
            </div>
            <button className="ml-2 h-9 px-4 rounded-xl bg-white hover:bg-zinc-200 text-zinc-950 font-bold text-xs uppercase tracking-wider transition-colors cursor-pointer">
              + Tune
            </button>
          </div>

          {/* Action Buttons (Clean Rounded-xl, No Glows) */}
          <div className="flex items-center gap-2">
            <button 
              onClick={() => setIsLiked(!isLiked)}
              className={`h-9 px-4 rounded-xl border text-xs font-semibold flex items-center gap-2 transition-colors cursor-pointer ${
                isLiked 
                  ? "bg-[#8c1cff] text-white border-[#8c1cff]" 
                  : "bg-[#141320] border-zinc-800 text-zinc-200 hover:bg-zinc-800"
              }`}
            >
              <ThumbsUp className={`w-3.5 h-3.5 ${isLiked ? "fill-white" : ""}`} />
              <span>47K</span>
            </button>

            <Link
              href="/stars"
              className="h-9 px-4 rounded-xl border border-amber-500/30 bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Star className="w-3.5 h-3.5 fill-amber-400" />
              <span>Send Star</span>
            </Link>

            <button className="h-9 px-3.5 rounded-xl border border-zinc-800 bg-[#141320] hover:bg-zinc-800 text-zinc-200 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer">
              <Share2 className="w-3.5 h-3.5 text-zinc-400" />
              <span>Share</span>
            </button>

            <button className="h-9 px-3.5 rounded-xl border border-zinc-800 bg-[#141320] hover:bg-zinc-800 text-zinc-200 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer">
              <Bookmark className="w-3.5 h-3.5 text-zinc-400" />
              <span>Save</span>
            </button>

            <button 
              onClick={() => setIsDownloadOpen(!isDownloadOpen)}
              className="h-9 px-3.5 rounded-xl border border-zinc-800 bg-[#141320] hover:bg-zinc-800 text-zinc-200 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-zinc-400" />
              <span>{downloadProgress ? `DL (${downloadProgress})` : "Download"}</span>
            </button>
          </div>
        </div>

        {/* Video Description Box (Rounded-2xl) */}
        <div className="p-4 bg-[#141320] border border-zinc-800 rounded-2xl text-xs text-zinc-300 space-y-2 leading-relaxed">
          <div className="flex items-center gap-3 font-bold text-white text-xs">
            <span>125,908 views</span>
            <span>•</span>
            <span>Premiered Oct 24, 2026</span>
            <span>•</span>
            <span className="text-[#8c1cff] uppercase">#MovieRecap #Oppenheimer</span>
          </div>
          <p className="text-zinc-400 leading-relaxed">
            Detailed storyline walkthrough, Christopher Nolan direction notes, and ethical dilemmas of J. Robert Oppenheimer decoded in Burmese. အဆုံးထိ ကြည့်ရှုပေးကြသော ပရိသတ်တစ်ဦးချင်းစီကို အထူးပင် ကျေးဇူးတင်ရှိပါသည်။
          </p>
        </div>

        {/* 💬 Comments Section (Placed Below Video) */}
        <div className="pt-4 border-t border-zinc-800/80 space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <span>Comments</span>
              <span className="text-xs text-zinc-400 font-mono">({chatMessages.length})</span>
            </h3>
            <span className="text-xs font-semibold text-zinc-400">Sort by: Top comments</span>
          </div>

          {/* Comment Input Box */}
          <form onSubmit={handleSendMessage} className="flex gap-3 items-start">
            <div className="w-9 h-9 rounded-full bg-red-600 flex items-center justify-center font-bold text-sm text-white shrink-0">
              T
            </div>
            <div className="flex-1 flex gap-2">
              <input
                type="text"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                placeholder="Add a comment on this recap..."
                className="flex-1 h-10 bg-[#141320] border border-zinc-800 rounded-xl px-4 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-white/30 transition-colors"
              />
              <button
                type="submit"
                className="h-10 px-5 rounded-xl bg-white hover:bg-zinc-200 text-zinc-950 text-xs font-bold transition-colors cursor-pointer shrink-0"
              >
                Comment
              </button>
            </div>
          </form>

          {/* Pinned Comment Card */}
          <div className="p-3.5 bg-[#141320] border border-zinc-800 rounded-xl text-xs space-y-2">
            <div className="flex items-center gap-2 text-zinc-400 text-[11px] font-semibold">
              <span className="text-amber-400">📌</span>
              <span className="text-zinc-300">Pinned by Min Mahar</span>
            </div>
            <div className="flex gap-3 items-start">
              <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-amber-700 to-amber-900 border border-zinc-700 flex items-center justify-center font-bold text-white text-xs shrink-0">
                M
              </div>
              <div className="space-y-1">
                <span className="font-bold text-white text-xs">Min Mahar</span>
                <p className="text-zinc-300 leading-relaxed">
                  နောက်ထပ် Christopher Nolan ရဲ့ ရုပ်ရှင်တွေထဲက ဘယ်ဇာတ်ကားကို Recap အရင်ကြည့်ချင်လဲခင်ဗျာ? Comments မှာ ရေးပေးခဲ့ကြပါဦး။
                </p>
              </div>
            </div>
          </div>

          {/* Comments Feed List */}
          <div className="space-y-4 pt-1">
            {chatMessages.map((user) => (
              <div key={user.id} className="flex gap-3 items-start">
                <div className={`w-8 h-8 rounded-full bg-gradient-to-tr ${user.avatar} font-bold text-xs flex items-center justify-center text-white shrink-0 border border-zinc-800`}>
                  {user.user.charAt(0)}
                </div>
                <div className="space-y-1 flex-1">
                  <div className="flex items-center gap-2 text-xs">
                    <span className="font-bold text-white">{user.user}</span>
                    <span className="text-[10px] text-zinc-500">2 hours ago</span>
                  </div>
                  <p className="text-xs text-zinc-300 leading-relaxed">{user.text}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* ============ RIGHT COLUMN: RELATED VIDEOS သီးသန့် (အချွန်စစ်စစ် rounded-none, No Star Badge, No Glow) ============ */}
      <div className="lg:col-span-4 flex flex-col space-y-3 w-full">
        <div className="flex items-center justify-between pb-1 border-b border-zinc-800/80">
          <h3 className="font-bold text-sm uppercase tracking-wider text-white">Up Next Videos</h3>
          <span className="text-xs font-semibold text-zinc-500 font-mono">Autoplay: ON</span>
        </div>

        {/* Related Video Cards သီးသန့်သာ အချွန် (rounded-none) စစ်စစ် */}
        <div className="space-y-2">
          {[
            { id: 2, title: "Myanmar Digital Banking Reform & Currency Value Analysis 2026", author: "Fintech MM", views: "48K views", time: "5 hours ago", duration: "22:15", bg: "from-blue-950/80 to-zinc-950" },
            { id: 3, title: "Solo Leveling: Ragnarok Episodes 1 to 15 (Motion Comic Recap)", author: "Comic Hub", views: "89K views", time: "1 day ago", duration: "29:40", bg: "from-emerald-950/80 to-zinc-950" },
            { id: 4, title: "The Art of War by Sun Tzu (Full Audiobook with Myanmar Explanation)", author: "Book Tube MM", views: "61K views", time: "3 days ago", duration: "45:10", bg: "from-purple-950/80 to-zinc-950" },
            { id: 5, title: "Cybersecurity Essentials for Myanmar Remote Workers & Devs", author: "Khit Tech", views: "32K views", time: "6 days ago", duration: "18:25", bg: "from-red-950/80 to-zinc-950" },
            { id: 6, title: "Black Myth Wukong Boss Fight Guide & Hidden Secrets", author: "Gamer MM", views: "115K views", time: "1 week ago", duration: "42:15", bg: "from-orange-950/80 to-zinc-950" },
          ].map((video) => (
            <Link
              key={video.id}
              href={`/watch/${video.id}`}
              className="w-full flex gap-3.5 p-1.5 hover:bg-white/5 rounded-xl transition-colors cursor-pointer group"
            >
              {/* Thumbnail (ဖုန်းပေါ်က အတိုင်း သန့်ပြန့်သော rounded-xl စတိုင်) */}
              <div className={`relative w-40 sm:w-44 aspect-video bg-gradient-to-tr ${video.bg} border border-white/10 rounded-xl shrink-0 overflow-hidden flex items-center justify-center shadow-md`}>
                <span className="absolute bottom-1.5 right-1.5 bg-black/85 font-mono text-[10px] font-bold text-zinc-200 px-1.5 py-0.5 rounded backdrop-blur-sm">
                  {video.duration}
                </span>
                <div className="w-8 h-8 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-opacity">
                  <Play className="w-4 h-4 fill-white ml-0.5" />
                </div>
              </div>

              {/* Video Info (စာလုံးအရွယ်အစားများ ကြီးမားရှင်းလင်းအောင် ချဲ့ထားသည်) */}
              <div className="flex flex-col justify-start flex-1 min-w-0 py-0.5">
                <h4 className="text-sm font-bold text-white group-hover:text-[#a042ff] transition-colors leading-snug line-clamp-2">
                  {video.title}
                </h4>
                <p className="text-xs text-zinc-400 font-medium mt-1.5 truncate">
                  {video.author}
                </p>
                <p className="text-xs text-zinc-500 mt-0.5">
                  {video.views} • {video.time}
                </p>
              </div>
            </Link>
          ))}
        </div>
      </div>

    </div>
  );
}