"use client";

import React, { useEffect, useState, useRef } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { layoutConfig } from "@/lib/layout-config";
import { NavIcon, NavIconName } from "@/components/layout/nav-icon";
import { 
  History, Bookmark, Download, Settings, 
  HelpCircle, LogOut, Crown, Ticket, ArrowUpRight, Tv, X
} from "lucide-react";

const navItems = [
  { href: "/", label: "Home", icon: "home" },
  { href: "/subscriptions", label: "Tuned", icon: "tuned" },
  { href: "/messages", label: "Messages", icon: "messages" },
  { href: "#", label: "Profile", isAvatar: true },
];

export function MobileBottomNav() {
  const pathname = usePathname();
  const [isScrollingDown, setIsScrollingDown] = useState(false);
  const [isSheetOpen, setIsSheetOpen] = useState(false);
  const lastScrollY = useRef(0);

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      if (currentScrollY <= 15) {
        setIsScrollingDown(false);
        lastScrollY.current = currentScrollY;
        return;
      }
      if (Math.abs(currentScrollY - lastScrollY.current) < 10) return;
      setIsScrollingDown(currentScrollY > lastScrollY.current);
      lastScrollY.current = currentScrollY;
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  if (layoutConfig.shouldHide(pathname, layoutConfig.hideMobileBottomNavRoutes)) {
    return null;
  }

  return (
    <>
      <nav 
        style={{ transform: isScrollingDown && !isSheetOpen ? "translate3d(0, 100%, 0)" : "translateZ(0)" }}
        className={`md:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#131224]/95 backdrop-blur-xl flex items-center justify-around py-2 px-1 transition-transform duration-300 ease-in-out`}
      >
        {navItems.map((item) => {
          const isActive = pathname === item.href || (item.isAvatar && isSheetOpen);
          
          if (item.isAvatar) {
            return (
              <button
                key="you"
                onClick={() => setIsSheetOpen(true)}
                className={`flex flex-col items-center justify-center gap-1 py-1 px-2.5 rounded-xl transition-colors cursor-pointer ${
                  isActive ? "text-[#a042ff]" : "text-zinc-400 hover:text-white"
                }`}
              >
                <div className={`w-6 h-6 rounded-full bg-red-600 flex items-center justify-center font-bold text-white text-xs transition-all ${isActive ? "border-2 border-[#a042ff] scale-110 shadow-[0_0_8px_#a042ff]" : "border border-white/20"}`}>
                  T
                </div>
                <span className={`text-[10px] tracking-tight ${isActive ? "font-bold text-white" : "font-medium text-zinc-400"}`}>
                  {item.label}
                </span>
              </button>
            );
          }

          return (
            <Link
              key={item.href}
              href={item.href}
              onClick={() => setIsSheetOpen(false)}
              className={`flex flex-col items-center justify-center gap-1 py-1 px-2.5 rounded-xl transition-colors ${
                isActive ? "text-[#a042ff]" : "text-zinc-400 hover:text-white"
              }`}
            >
              <NavIcon name={item.icon as any} isActive={isActive} className={`w-5 h-5 ${isActive ? "text-[#a042ff]" : "text-zinc-400"}`} />
              <span className={`text-[10px] tracking-tight ${isActive ? "font-bold text-white" : "font-medium text-zinc-400"}`}>
                {item.label}
              </span>
            </Link>
          );
        })}
      </nav>

      {/* 📱 FAKE BOTTOM SHEET FOR MOBILE "YOU" TAB */}
      <div 
        className={`md:hidden fixed inset-0 z-50 transition-opacity duration-300 ${isSheetOpen ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"}`}
      >
        {/* Backdrop */}
        <div 
          onClick={() => setIsSheetOpen(false)} 
          className="absolute inset-0 bg-black/60 backdrop-blur-sm"
        />

        {/* Sheet Content (Slide Up) */}
        <div 
          className={`absolute bottom-0 left-0 right-0 bg-[#181628] rounded-t-3xl border-t border-white/10 shadow-[0_-10px_40px_rgba(0,0,0,0.5)] transition-transform duration-300 ease-out flex flex-col max-h-[85vh] ${isSheetOpen ? "translate-y-0" : "translate-y-full"}`}
        >
          {/* Drag Handle (Visual Only) */}
          <div className="w-12 h-1.5 bg-white/15 rounded-full mx-auto my-3 shrink-0" />
          
          <div className="overflow-y-auto px-5 pb-8 space-y-5 scrollbar-none">
            {/* Header: User Info */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="relative w-12 h-12 rounded-full bg-red-600 flex items-center justify-center font-bold text-lg text-white shadow-sm ring-2 ring-amber-400/80">
                  T
                  <span className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-amber-400 flex items-center justify-center text-[9px] text-zinc-950 font-black shadow">
                    👑
                  </span>
                </div>
                <div className="flex flex-col">
                  <div className="flex items-center gap-1.5">
                    <span className="text-base font-bold text-white">Thomas Viewer</span>
                    <span className="text-[9px] font-black uppercase bg-gradient-to-r from-amber-400 to-amber-500 text-zinc-950 px-1.5 py-0.2 rounded font-mono shadow-sm">
                      PREMIUM
                    </span>
                  </div>
                  <span className="text-xs text-zinc-400">@thomas_viewer</span>
                </div>
              </div>
              <button onClick={() => setIsSheetOpen(false)} className="p-2 bg-white/5 rounded-full text-zinc-400 hover:text-white transition-colors">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* VIP Card (Khit Premium Status) */}
            <Link
              href="/pass"
              onClick={() => setIsSheetOpen(false)}
              className="block p-3.5 rounded-2xl bg-gradient-to-r from-amber-500/15 via-[#8c1cff]/10 to-amber-500/10 border border-amber-500/30 flex flex-col gap-2 transition-all active:scale-[0.98]"
            >
              <div className="flex items-center justify-between">
                <span className="text-sm font-black text-amber-300 flex items-center gap-2">
                  <Crown className="w-4 h-4 text-amber-400 fill-amber-400" />
                  Khit Premium
                </span>
                <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/20 px-2 py-0.5 rounded border border-emerald-500/30">Active</span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="flex items-center gap-1.5 text-zinc-400">
                  <Ticket className="w-3.5 h-3.5 text-amber-400" /> 1 Lottery Ticket • Ad-Free
                </span>
                <span className="text-amber-400 font-bold">10% Pool ➔</span>
              </div>
            </Link>

            {/* Main Tools (Grid) */}
            <div className="grid grid-cols-3 gap-3">
              <Link href="/history" onClick={() => setIsSheetOpen(false)} className={`flex flex-col items-center justify-center gap-2 p-3 rounded-2xl transition-colors ${pathname === "/history" ? "bg-[#fc5b69]/10 border border-[#fc5b69]/50 text-white shadow-sm" : "bg-[#131224] border border-white/5 text-zinc-300 hover:text-white"}`}>
                <History className={`w-5 h-5 ${pathname === "/history" ? "text-[#fc5b69]" : "text-[#fc5b69]/70"}`} />
                <span className="text-[11px] font-bold">History</span>
              </Link>
              <Link href="/saved" onClick={() => setIsSheetOpen(false)} className={`flex flex-col items-center justify-center gap-2 p-3 rounded-2xl transition-colors ${pathname === "/saved" ? "bg-[#8c1cff]/10 border border-[#8c1cff]/50 text-white shadow-sm" : "bg-[#131224] border border-white/5 text-zinc-300 hover:text-white"}`}>
                <Bookmark className={`w-5 h-5 ${pathname === "/saved" ? "text-[#8c1cff]" : "text-[#8c1cff]/70"}`} />
                <span className="text-[11px] font-bold">Saved</span>
              </Link>
              <Link href="/downloads" onClick={() => setIsSheetOpen(false)} className={`flex flex-col items-center justify-center gap-2 p-3 rounded-2xl transition-colors ${pathname === "/downloads" ? "bg-emerald-500/10 border border-emerald-500/50 text-white shadow-sm" : "bg-[#131224] border border-white/5 text-zinc-300 hover:text-white"}`}>
                <Download className={`w-5 h-5 ${pathname === "/downloads" ? "text-emerald-400" : "text-emerald-400/70"}`} />
                <span className="text-[11px] font-bold">Downloads</span>
              </Link>
            </div>

            {/* Other Actions List */}
            <div className="bg-[#131224] border border-white/5 rounded-2xl overflow-hidden">
              <Link href="/channel/minmahar" onClick={() => setIsSheetOpen(false)} className={`flex items-center justify-between p-3.5 border-b border-white/5 text-sm font-semibold transition-colors ${pathname.startsWith("/channel") ? "bg-white/10 text-white" : "text-zinc-300 hover:bg-white/5"}`}>
                <div className="flex items-center gap-3"><Tv className={`w-4 h-4 ${pathname.startsWith("/channel") ? "text-white" : "text-zinc-400"}`} /> My Channel Hub</div>
                <ArrowUpRight className={`w-4 h-4 ${pathname.startsWith("/channel") ? "text-white" : "text-zinc-500"}`} />
              </Link>
              <Link href="/settings" onClick={() => setIsSheetOpen(false)} className={`w-full flex items-center justify-between p-3.5 border-b border-white/5 text-sm font-semibold transition-colors text-left ${pathname === "/settings" ? "bg-white/10 text-white" : "text-zinc-300 hover:bg-white/5"}`}>
                <div className="flex items-center gap-3"><Settings className={`w-4 h-4 ${pathname === "/settings" ? "text-white" : "text-zinc-400"}`} /> Settings</div>
              </Link>
              <Link href="/settings" onClick={() => setIsSheetOpen(false)} className="w-full flex items-center justify-between p-3.5 border-b border-white/5 text-sm font-semibold text-zinc-300 hover:bg-white/5 text-left">
                <div className="flex items-center gap-3"><HelpCircle className="w-4 h-4 text-zinc-400" /> Help & Feedback</div>
              </Link>
              <button className="w-full flex items-center justify-between p-3.5 text-sm font-semibold text-red-400 hover:bg-red-500/10 text-left">
                <div className="flex items-center gap-3"><LogOut className="w-4 h-4" /> Sign Out</div>
              </button>
            </div>

          </div>
        </div>
      </div>
    </>
  );
}