export default function Loading() {
  return (
    <div className="px-4 sm:px-8 pb-16 pt-2 space-y-4 max-w-[1700px] mx-auto w-full animate-pulse">
      
      {/* ၁။ Categories Pills Skeleton (Edge-to-edge scroll view) */}
      <div className="flex items-center gap-2.5 overflow-x-hidden pb-1 -mx-4 px-4 sm:-mx-8 sm:px-8">
        {[...Array(7)].map((_, i) => (
          <div key={i} className="h-9 w-24 bg-[#1c1a27] rounded-2xl shrink-0 border border-white/5" />
        ))}
      </div>

      {/* ၂။ Section Title Skeleton */}
      <div className="pt-2 flex items-center justify-between">
        <div className="h-7 w-64 bg-[#1c1a27] rounded-lg border border-white/5" />
      </div>

      {/* ၃။ Video Cards Grid Skeleton (၃ ကော်လံ) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {[...Array(9)].map((_, i) => (
          <div key={i} className="flex flex-col gap-2.5">
            {/* Thumbnail Box */}
            <div className="w-full aspect-[16/9] rounded-xl bg-[#1c1a27] border border-white/5" />
            
            {/* Avatar & Text Details */}
            <div className="flex items-start gap-3 px-0.5">
              {/* Avatar Circle */}
              <div className="w-10 h-10 rounded-full bg-[#1c1a27] shrink-0 border border-white/5" />
              
              {/* Text Lines */}
              <div className="flex-1 space-y-2 py-1">
                <div className="w-[90%] h-4 bg-[#1c1a27] rounded-md" />
                <div className="w-[70%] h-4 bg-[#1c1a27] rounded-md" />
                <div className="w-[45%] h-3 bg-[#1c1a27]/60 rounded-md mt-1.5" />
              </div>
            </div>
          </div>
        ))}
      </div>

    </div>
  );
}