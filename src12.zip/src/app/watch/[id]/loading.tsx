export default function WatchLoading() {
  return (
    <div className="w-full min-h-screen bg-[#131224] animate-pulse">
      
      {/* 📱 Mobile Watch Skeleton (၄:၃ Video Player နှင့် အောက်က အကွက်များ) */}
      <div className="md:hidden flex flex-col w-full">
        {/* Player Skeleton */}
        <div className="w-full aspect-[4/3] bg-[#1c1a27] border-b border-white/5" />
        
        {/* Info & Creator Skeleton */}
        <div className="p-4 space-y-4">
          <div className="h-6 w-[85%] bg-[#1c1a27] rounded-xl" />
          <div className="h-4 w-40 bg-[#1c1a27]/60 rounded-md" />
          
          <div className="flex items-center justify-between pt-2">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-[#1c1a27]" />
              <div className="space-y-1.5">
                <div className="h-4 w-28 bg-[#1c1a27] rounded" />
                <div className="h-3 w-20 bg-[#1c1a27]/60 rounded" />
              </div>
            </div>
            <div className="h-9 w-24 bg-[#1c1a27] rounded-full" />
          </div>

          {/* Action Buttons Skeleton */}
          <div className="flex gap-2.5 pt-2 overflow-x-hidden">
            <div className="h-9 w-24 bg-[#1c1a27] rounded-full shrink-0" />
            <div className="h-9 w-20 bg-[#1c1a27] rounded-full shrink-0" />
            <div className="h-9 w-20 bg-[#1c1a27] rounded-full shrink-0" />
          </div>

          {/* Tabs Skeleton */}
          <div className="flex gap-6 border-b border-white/5 pt-4 pb-2.5">
            <div className="h-5 w-16 bg-[#1c1a27] rounded" />
            <div className="h-5 w-24 bg-[#1c1a27] rounded" />
          </div>

          {/* Content items */}
          <div className="space-y-3 pt-2">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="flex gap-3">
                <div className="w-36 aspect-[16/9] bg-[#1c1a27] rounded-xl shrink-0" />
                <div className="flex-1 space-y-2 py-1">
                  <div className="h-4 w-full bg-[#1c1a27] rounded" />
                  <div className="h-3 w-24 bg-[#1c1a27]/60 rounded" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 💻 Desktop Watch Skeleton (၁၆:၉ Video Player နှင့် Live Chat အကွက်) */}
      <div className="hidden md:grid px-4 sm:px-8 pb-12 pt-2 w-full grid-cols-1 lg:grid-cols-12 gap-6 items-start max-w-[1700px] mx-auto">
        {/* Left Column (Video + Info) */}
        <div className="lg:col-span-8 space-y-4">
          <div className="w-full aspect-[16/9] bg-[#1c1a27] rounded-3xl border border-white/5" />
          <div className="h-8 w-3/4 bg-[#1c1a27] rounded-xl" />
          <div className="flex items-center gap-4 pt-2">
            <div className="w-12 h-12 rounded-full bg-[#1c1a27]" />
            <div className="space-y-2">
              <div className="h-5 w-36 bg-[#1c1a27] rounded" />
              <div className="h-3 w-24 bg-[#1c1a27]/60 rounded" />
            </div>
          </div>
        </div>

        {/* Right Column (Chat Pane) */}
        <div className="lg:col-span-4 space-y-4">
          <div className="h-[480px] w-full bg-[#1c1a27] rounded-3xl border border-white/5" />
          <div className="h-[200px] w-full bg-[#1c1a27] rounded-3xl border border-white/5" />
        </div>
      </div>

    </div>
  );
}