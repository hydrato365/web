"use client";

import React from "react";
import { ChannelHeader } from "@/components/channel/channel-header";
import { ChannelTabs } from "@/components/channel/channel-tabs";

export default function CreatorChannelPage() {
  return (
    <div className="min-h-screen relative z-10 animate-in fade-in duration-300 pb-16">
      <ChannelHeader />
      <ChannelTabs />
    </div>
  );
}