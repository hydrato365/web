"use client";

import React, { useRef, useEffect } from "react";
import Link from "next/link";
import Hls from "hls.js";
import { useRouter } from "next/navigation";
import { 
  ChevronDown, Pause, Play, Maximize, PictureInPicture, CheckCircle2, 
  ThumbsUp, Bookmark, Share2, Star 
} from "lucide-react";

interface MobilePlayerProps {
  videoUrl: string;
  activeTab: "upnext" | "comments";
  isMobileInputFocused: boolean;
  isPlaying: boolean;
  setIsPlaying: (val: boolean) => void;
  isLiked: boolean;
  setIsLiked: (val: boolean) => void;
}

export function MobilePlayer({
  videoUrl,
  activeTab,
  isMobileInputFocused,
  isPlaying,
  setIsPlaying,
  isLiked,
  setIsLiked
}: MobilePlayerProps) {
  const router = useRouter();
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    const video = videoRef.current;
    if (!video || !videoUrl) return;

    if (videoUrl.includes(".m3u8")) {
      if (Hls.isSupported()) {
        const hls = new Hls();
        hls.loadSource(videoUrl);
        hls.attachMedia(video);
        hls.on(Hls.Events.MANIFEST_PARSED, () => {
          if (isPlaying) video.play().catch(() => setIsPlaying(false));
        });
        return () => hls.destroy();
      } else if (video.canPlayType("application/vnd.apple.mpegurl")) {
        video.src = videoUrl;
      }
    } else {
      video.src = videoUrl;
    }
  }, [videoUrl]);

  // Play/Pause ကို React State ဖြင့် ချိတ်ဆက်ခြင်း
  useEffect(() => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.play().catch(() => setIsPlaying(false));
      } else {
        videoRef.current.pause();
      }
    }
  }, [isPlaying, setIsPlaying]);

  // တကယ့် Native OS PiP ကို ခေါ်မည့် Function
  const togglePiP = async () => {
    try {
      if (document.pictureInPictureElement) {
        await document.exitPictureInPicture();
      } else if (videoRef.current && document.pictureInPictureEnabled) {
        await videoRef.current.requestPictureInPicture();
      }
    } catch (error) {
      console.error("PiP failed to launch", error);
    }
  };

  return (
    <>
      {/* Sticky Video Player (၁၆:၉ Widescreen အချိုးဖြင့် သဘာဝကျစွာ ပြသခြင်း) */}
      <div className={`w-full aspect-video bg-black overflow-hidden shadow-2xl z-30 group/player touch-none ${activeTab === "comments" && isMobileInputFocused ? "relative" : "sticky top-0"}`}>
        
        {/* 🎬 တကယ့် အစစ်အမှန် Video HTML5 Element */}
        <video
          ref={videoRef}
          src={videoUrl}
          className="absolute inset-0 w-full h-full object-cover"
          playsInline
          loop
          onClick={() => setIsPlaying(!isPlaying)}
        />

        <div className="absolute top-3 left-3 right-3 flex items-center justify-between z-20 pointer-events-auto">
          <button
            onClick={() => window.history.length > 1 ? router.back() : router.push('/')}
            className="w-9 h-9 rounded-full bg-black/50 backdrop-blur-md border border-white/15 flex items-center justify-center text-white active:scale-90 transition-transform cursor-pointer shadow-lg"
          >
            <ChevronDown className="w-5 h-5" />
          </button>
          <span className="text-[10px] font-bold text-zinc-300 bg-black/50 backdrop-blur-md px-2.5 py-1 rounded-full border border-white/10">
            1080p • 60fps
          </span>
        </div>

        {/* 🎛️ Mobile Player Controls (Row 2 တန်းခွဲထားပြီး Seeking Bar ကို အပြည့်ပေးထားခြင်း) */}
        <div className="absolute bottom-0 left-0 right-0 pt-6 pb-2 px-3 bg-gradient-to-t from-black/85 via-black/40 to-transparent flex flex-col gap-2 pointer-events-auto">
          
          {/* Row 1: Play/Pause, Live Badge, Time နှင့် Maximize ခလုတ် */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <button 
                onClick={() => setIsPlaying(!isPlaying)} 
                className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white active:scale-95 transition-transform cursor-pointer"
              >
                {isPlaying ? <Pause className="w-4 h-4 fill-white" /> : <Play className="w-4 h-4 fill-white ml-0.5" />}
              </button>

              <div className="px-2 py-0.5 bg-red-600 rounded text-white font-extrabold text-[9px] uppercase flex items-center gap-1 tracking-wider shrink-0">
                <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" /> LIVE
              </div>

              <span className="text-[11px] font-mono font-medium text-white/90">17:34 / 59:32</span>
            </div>

            <div className="flex items-center gap-2">
              <button 
                onClick={togglePiP}
                className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white active:scale-95 transition-transform cursor-pointer"
                title="Picture in Picture"
              >
                <PictureInPicture className="w-4 h-4" />
              </button>
              <button 
                className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white active:scale-95 transition-transform cursor-pointer"
                title="Fullscreen"
              >
                <Maximize className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Row 2: ဖုန်းစခရင် အပြည့် လက်မဖြင့် လွတ်လပ်စွာ ဆွဲနိုင်သော Full-width Seeking Bar */}
          <div className="w-full h-3 flex items-center cursor-pointer group/seek relative">
            <div className="w-full h-1 bg-white/30 rounded-full relative overflow-visible">
              <div className="h-full w-1/3 bg-[#8c1cff] rounded-l-full relative shadow-[0_0_8px_#8c1cff]" />
              <div 
                className="w-3.5 h-3.5 bg-white rounded-full absolute top-1/2 -translate-y-1/2 -ml-1.5 shadow-md scale-100 group-hover/seek:scale-125 transition-transform" 
                style={{ left: '33%' }} 
              />
            </div>
          </div>

        </div>
      </div>

      {/* 📱 Mobile Info & Clean Actions Architecture */}
      <div className="flex flex-col px-3 pt-3 pb-1">
        
        {/* Row 1: Title (Compact & Clean) */}
        <h1 className="text-[15px] sm:text-base font-bold leading-snug text-white line-clamp-2">
          Oppenheimer Full Movie Recap - The Father of the Atomic Bomb
        </h1>

        {/* Row 2: Views, Date & Category */}
        <div className="flex items-center gap-1.5 text-[11px] text-zinc-400 font-medium mt-1">
          <span>125K views</span>
          <span>•</span>
          <span>2 hours ago</span>
          <span>•</span>
          <span className="text-[#8c1cff] font-semibold">Movie Recap</span>
          <span className="font-bold text-zinc-300 ml-auto cursor-pointer">...more</span>
        </div>

        {/* Row 3: Dedicated Creator Row (Channel Name မည်မျှရှည်စေကာမူ ကျယ်ဝန်းစွာ ဖော်ပြနိုင်ပြီး Tune ခလုတ်ကို ညာဘက်တွင် သေသပ်စွာ နေရာချသည်) */}
        <div className="mt-3 flex items-center justify-between gap-3">
          <Link href="/channel/minmahar" className="flex items-center gap-2.5 min-w-0 flex-1">
            <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-amber-600 to-amber-900 border border-white/10 flex items-center justify-center font-bold text-white text-xs shrink-0">
              M
            </div>
            <div className="flex flex-col min-w-0">
              <div className="flex items-center gap-1">
                <span className="text-sm font-bold text-white truncate">
                  Min Mahar
                </span>
                <CheckCircle2 className="w-3.5 h-3.5 text-blue-500 fill-blue-500 text-[#131224] shrink-0" />
              </div>
              <span className="text-[10px] text-zinc-400">1.98M Tuned</span>
            </div>
          </Link>

          <button className="h-8 px-4 bg-white text-zinc-950 text-xs font-bold rounded-full shrink-0 active:scale-95 transition-transform shadow-sm">
            + Tune
          </button>
        </div>

        {/* Row 4: Dedicated Action Buttons Row (Unlike မပါဘဲ Like, Star, Share, Save သီးသန့် အောက်တန်း၌ ကျယ်ဝန်းစွာ စီထားသည်) */}
        <div className="mt-3 flex items-center gap-2 overflow-x-auto scrollbar-none -mx-3 px-3 pb-1">
          
          {/* Like Button */}
          <button 
            onClick={() => setIsLiked(!isLiked)} 
            className={`h-8 px-4 shrink-0 rounded-full flex items-center gap-1.5 text-xs font-bold transition-all ${
              isLiked 
                ? "bg-[#8c1cff] text-white shadow-md shadow-[#8c1cff]/30" 
                : "bg-[#232130] text-zinc-200 hover:bg-[#2c2a3b]"
            }`}
          >
            <ThumbsUp className={`w-3.5 h-3.5 ${isLiked ? "fill-white" : ""}`} /> 
            <span>{isLiked ? "47K" : "47K"}</span>
          </button>

          {/* Star Button */}
          <Link 
            href="/stars" 
            className="h-8 px-4 shrink-0 bg-amber-500/10 border border-amber-500/20 text-amber-400 hover:bg-amber-500/20 rounded-full flex items-center gap-1.5 text-xs font-bold transition-all shadow-sm"
          >
            <Star className="w-3.5 h-3.5 fill-amber-400" /> 
            <span>Star</span>
          </Link>

          {/* Share Button */}
          <button className="h-8 px-4 shrink-0 bg-[#232130] hover:bg-[#2c2a3b] text-zinc-200 rounded-full flex items-center gap-1.5 text-xs font-bold transition-colors">
            <Share2 className="w-3.5 h-3.5 text-zinc-400" /> 
            <span>Share</span>
          </button>

          {/* Save Button */}
          <button className="h-8 px-4 shrink-0 bg-[#232130] hover:bg-[#2c2a3b] text-zinc-200 rounded-full flex items-center gap-1.5 text-xs font-bold transition-colors">
            <Bookmark className="w-3.5 h-3.5 text-zinc-400" /> 
            <span>Save</span>
          </button>

        </div>

      </div>
    </>
  );
}