"use client";

import React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { 
  ChevronDown, Pause, Play, Maximize, CheckCircle2, 
  ThumbsUp, Bookmark, Share2, Star 
} from "lucide-react";

interface MobilePlayerProps {
  activeTab: "upnext" | "comments";
  isMobileInputFocused: boolean;
  isPlaying: boolean;
  setIsPlaying: (val: boolean) => void;
  isLiked: boolean;
  setIsLiked: (val: boolean) => void;
}

export function MobilePlayer({
  activeTab,
  isMobileInputFocused,
  isPlaying,
  setIsPlaying,
  isLiked,
  setIsLiked
}: MobilePlayerProps) {
  const router = useRouter();

  return (
    <>
      {/* Sticky Video Player (၄:၃ အချိုးဖြင့် ဖုန်းစခရင်တွင် ပိုမိုကြီးမား ကျယ်ပြန့်စေခြင်း) */}
      <div className={`w-full aspect-[4/3] bg-black overflow-hidden shadow-2xl z-30 ${activeTab === "comments" && isMobileInputFocused ? "relative" : "sticky top-0"}`}>
        <div 
          className="absolute inset-0 bg-zinc-900 bg-center bg-cover flex items-center justify-center" 
          style={{ backgroundImage: `url('https://images.unsplash.com/photo-1564982755866-9e8c37d8009d?q=80&w=2000&auto=format&fit=crop')` }}
        >
          <div className="w-32 h-32 bg-amber-500/20 blur-[50px] rounded-full translate-x-12 translate-y-10" />
        </div>

        <div className="absolute top-3 left-3 right-3 flex items-center justify-between z-20 pointer-events-auto">
          <button
            onClick={() => window.history.length > 1 ? router.back() : router.push('/')}
            className="w-9 h-9 rounded-full bg-black/50 backdrop-blur-md border border-white/15 flex items-center justify-center text-white active:scale-90 transition-transform cursor-pointer shadow-lg"
          >
            <ChevronDown className="w-5 h-5" />
          </button>
          <span className="text-[10px] font-bold text-zinc-300 bg-black/50 backdrop-blur-md px-2.5 py-1 rounded-full border border-white/10">
            1080p • 60fps
          </span>
        </div>

        {/* 🎛️ Mobile Player Controls (Row 2 တန်းခွဲထားပြီး Seeking Bar ကို အပြည့်ပေးထားခြင်း) */}
        <div className="absolute bottom-0 left-0 right-0 pt-6 pb-2 px-3 bg-gradient-to-t from-black/85 via-black/40 to-transparent flex flex-col gap-2 pointer-events-auto">
          
          {/* Row 1: Play/Pause, Live Badge, Time နှင့် Maximize ခလုတ် */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <button 
                onClick={() => setIsPlaying(!isPlaying)} 
                className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white active:scale-95 transition-transform cursor-pointer"
              >
                {isPlaying ? <Pause className="w-4 h-4 fill-white" /> : <Play className="w-4 h-4 fill-white ml-0.5" />}
              </button>

              <div className="px-2 py-0.5 bg-red-600 rounded text-white font-extrabold text-[9px] uppercase flex items-center gap-1 tracking-wider shrink-0">
                <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" /> LIVE
              </div>

              <span className="text-[11px] font-mono font-medium text-white/90">17:34 / 59:32</span>
            </div>

            <button 
              className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white active:scale-95 transition-transform cursor-pointer"
              title="Fullscreen"
            >
              <Maximize className="w-4 h-4" />
            </button>
          </div>

          {/* Row 2: ဖုန်းစခရင် အပြည့် လက်မဖြင့် လွတ်လပ်စွာ ဆွဲနိုင်သော Full-width Seeking Bar */}
          <div className="w-full h-3 flex items-center cursor-pointer group/seek relative">
            <div className="w-full h-1 bg-white/30 rounded-full relative overflow-visible">
              <div className="h-full w-1/3 bg-[#8c1cff] rounded-l-full relative shadow-[0_0_8px_#8c1cff]" />
              <div 
                className="w-3.5 h-3.5 bg-white rounded-full absolute top-1/2 -translate-y-1/2 -ml-1.5 shadow-md scale-100 group-hover/seek:scale-125 transition-transform" 
                style={{ left: '33%' }} 
              />
            </div>
          </div>

        </div>
      </div>

      {/* Mobile Info & Actions */}
      <div className="flex flex-col px-4 pt-4 pb-2">
        <h1 className="text-xl font-bold leading-snug text-white">
          Oppenheimer Full Movie Recap - The Father of the Atomic Bomb
        </h1>

        <div className="flex items-center gap-2 text-xs text-zinc-400 font-medium mt-2">
          <span>125K views</span>
          <span>•</span>
          <span>2 hours ago</span>
          <span>•</span>
          <span className="text-red-500 font-semibold">Movie Recap</span>
        </div>

        <div className="mt-4 p-3 bg-[#232130] rounded-xl text-xs text-zinc-300 cursor-pointer border border-white/5 flex flex-col gap-1">
          <p className="line-clamp-2">Detailed storyline walkthrough, Christopher Nolan direction notes, and ethical dilemmas of J. Robert Oppenheimer decoded in Burmese.</p>
          <span className="text-red-400 font-bold">...more</span>
        </div>

        <div className="mt-5 flex items-center justify-between">
          <Link href="/channel/minmahar" className="flex items-center gap-3 group cursor-pointer">
            <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-amber-600 to-amber-900 border border-[#1e1c2a] flex items-center justify-center font-bold text-white text-sm">
              M
            </div>
            <div className="flex flex-col">
              <h3 className="text-base font-bold text-white flex items-center gap-1.5 group-hover:text-[#a042ff] transition-colors">
                Min Mahar
                <CheckCircle2 className="w-3.5 h-3.5 text-blue-500 fill-blue-500 text-[#131224]" />
              </h3>
              <span className="text-xs text-zinc-400">1.98M Tuned</span>
              </div>
            </Link>
            
            <button className="h-9 px-4 bg-red-600 text-white text-sm font-bold rounded-full transition-transform active:scale-95 shadow-md shadow-red-600/20">
              + Tune
            </button>
        </div>

        <div className="mt-5 flex items-center gap-2.5 overflow-x-auto scrollbar-none pb-2 -mx-4 px-4">
          <button onClick={() => setIsLiked(!isLiked)} className="h-9 px-4 shrink-0 bg-[#232130] rounded-full flex items-center gap-2 text-xs font-bold text-white">
            <ThumbsUp className={`w-4 h-4 ${isLiked ? "fill-white" : ""}`} /> {isLiked ? "47,988" : "47,987"}
          </button>
          <button className="h-9 px-4 shrink-0 bg-[#232130] rounded-full flex items-center gap-2 text-xs font-bold text-white">
            <Bookmark className="w-4 h-4" /> Save
          </button>
          <button className="h-9 px-4 shrink-0 bg-[#232130] rounded-full flex items-center gap-2 text-xs font-bold text-white">
            <Share2 className="w-4 h-4" /> Share
          </button>
          <Link href="/stars" className="h-9 px-4 shrink-0 bg-amber-400 text-zinc-950 rounded-full flex items-center gap-2 text-xs font-black shadow-md shadow-amber-500/20">
            <Star className="w-4 h-4 fill-zinc-950" /> Send Star
          </Link>
        </div>
      </div>
    </>
  );
}