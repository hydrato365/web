"use client";

import React from "react";
import Link from "next/link";
import { 
  Heart, Share2, Eye, LineChart, Bell, Send, 
  MoreHorizontal, CheckCircle2, Volume2, Maximize, 
  Play, Pause, Download, ChevronDown, Users
} from "lucide-react";

interface ChatMessage {
  id: number;
  user: string;
  online: boolean;
  check: boolean;
  avatar: string;
  text: string;
}

interface DesktopViewProps {
  isPlaying: boolean;
  setIsPlaying: (val: boolean) => void;
  isDownloadOpen: boolean;
  setIsDownloadOpen: (val: boolean) => void;
  downloadProgress: string | null;
  handleDownload: (quality: string) => void;
  isLiked: boolean;
  setIsLiked: (val: boolean) => void;
  chatMessages: ChatMessage[];
  inputMessage: string;
  setInputMessage: (val: string) => void;
  handleSendMessage: (e: React.FormEvent) => void;
}

export function DesktopView({
  isPlaying,
  setIsPlaying,
  isDownloadOpen,
  setIsDownloadOpen,
  downloadProgress,
  handleDownload,
  isLiked,
  setIsLiked,
  chatMessages,
  inputMessage,
  setInputMessage,
  handleSendMessage
}: DesktopViewProps) {
  return (
    <div className="hidden md:grid px-4 sm:px-8 pb-12 pt-2 w-full grid-cols-1 lg:grid-cols-12 gap-6 items-start relative z-10 max-w-[1700px] mx-auto">
      
      {/* ============ LEFT COLUMN: VIDEO + METADATA ============ */}
      <div className="lg:col-span-8 flex flex-col">
        
        {/* 🎬 Video Player */}
        <div className="w-full aspect-[16/9] bg-black rounded-3xl overflow-hidden relative shadow-2xl group border border-white/5">
          <div 
            className="absolute inset-0 bg-zinc-900 bg-center bg-cover flex items-center justify-center" 
            style={{ backgroundImage: `url('https://images.unsplash.com/photo-1564982755866-9e8c37d8009d?q=80&w=2000&auto=format&fit=crop')` }}
          >
            <div className="w-32 h-32 bg-amber-500/20 blur-[50px] rounded-full translate-x-12 translate-y-10" />
          </div>
          
          <div className="absolute bottom-5 left-5 right-5 p-4 rounded-2xl bg-black/40 backdrop-blur-md border border-white/10 flex items-center justify-between gap-4">
            <div className="flex items-center gap-4 w-full">
              <div className="px-3 py-1 bg-red-600 rounded-lg text-white font-extrabold text-[10px] uppercase flex items-center gap-1.5 tracking-wider">
                <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" /> LIVE
              </div>

              <button 
                onClick={() => setIsPlaying(!isPlaying)}
                className="text-white hover:scale-110 transition-transform cursor-pointer"
              >
                {isPlaying ? <Pause className="w-4 h-4 fill-white" /> : <Play className="w-4 h-4 fill-white" />}
              </button>

              <div className="flex-1 h-1 bg-white/20 rounded-full cursor-pointer relative overflow-visible flex items-center">
                <div className="h-full w-1/3 bg-[#8c1cff] rounded-l-full relative shadow-[0_0_10px_#8c1cff]" />
                <div className="w-3 h-3 bg-white rounded-full absolute shadow-md cursor-grab" style={{ left: '33%' }} />
              </div>
              
              <span className="text-xs font-mono font-medium text-white px-2">17:34 / 59:32</span>

              <button className="text-white hover:text-red-400 transition-colors"><Volume2 className="w-4 h-4" /></button>
              <button className="text-white hover:text-red-400 transition-colors"><Maximize className="w-4 h-4" /></button>
            </div>
          </div>
        </div>

        {/* Creator Row & Info */}
        <div className="mt-4 flex flex-col md:flex-row justify-between items-start gap-6">
          
          <div className="flex-1 max-w-2xl">
            <Link href="/channel/minmahar" className="flex items-center gap-3.5 group cursor-pointer w-max">
              <div className="relative group-hover:scale-105 transition-transform">
                <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-amber-600 to-amber-900 border border-[#1e1c2a] font-bold text-white flex items-center justify-center">
                  M
                </div>
                <div className="absolute -bottom-1 -right-1 bg-blue-500 rounded-full w-4 h-4 border-2 border-[#14121d] flex items-center justify-center">
                  <CheckCircle2 className="w-2.5 h-2.5 text-white" />
                </div>
              </div>
              <div className="flex flex-col">
                <h3 className="text-lg font-bold text-white flex items-center gap-2 group-hover:text-[#a042ff] transition-colors">
                  Min Mahar
                </h3>
                <span className="text-sm font-medium text-zinc-400">1,980,893 Tuned</span>
              </div>
            </Link>

            <h1 className="mt-5 text-2xl sm:text-3xl font-black tracking-tight leading-snug text-white">
              Oppenheimer Full Movie Recap - The Father of the Atomic Bomb
            </h1>

            <div className="mt-5 space-y-4 text-base font-normal text-zinc-200 leading-relaxed pr-4">
              <p>Detailed storyline walkthrough, Christopher Nolan direction notes, and ethical dilemmas of J. Robert Oppenheimer decoded in Burmese.</p>
            </div>
          </div>

          {/* Action Buttons Row */}
          <div className="flex flex-col gap-6 md:w-72 shrink-0 md:pt-2">
            <div className="flex items-center gap-2.5">
              <div className="relative flex-1">
                <button 
                  onClick={() => setIsDownloadOpen(!isDownloadOpen)}
                  className="w-full h-11 bg-[#1c1a27] hover:bg-[#232031] border border-white/5 transition-colors rounded-xl flex items-center justify-center gap-2 text-sm font-bold text-zinc-200 cursor-pointer"
                >
                  <Download className="w-4 h-4 text-red-500" />
                  <span>{downloadProgress ? `DL (${downloadProgress})` : "DL"}</span>
                  <ChevronDown className="w-3.5 h-3.5 text-zinc-400" />
                </button>

                {isDownloadOpen && (
                  <>
                    <div onClick={() => setIsDownloadOpen(false)} className="fixed inset-0 z-40" />
                    <div className="absolute left-0 top-12 w-44 bg-[#181822] border border-white/10 rounded-2xl p-1.5 shadow-2xl z-50 animate-in fade-in zoom-in-95 space-y-0.5">
                      <p className="text-[10px] font-bold text-zinc-400 px-3 py-1 uppercase tracking-wider">Select Quality</p>
                      {[
                        { res: "1080p (FHD)", size: "480 MB" },
                        { res: "720p (HD)", size: "220 MB" },
                        { res: "360p (Saver)", size: "95 MB" },
                      ].map((q) => (
                        <button
                          key={q.res}
                          onClick={() => handleDownload(q.res.split(" ")[0])}
                          className="w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium text-zinc-300 hover:bg-zinc-800 hover:text-white transition-colors cursor-pointer"
                        >
                          <span>{q.res}</span>
                          <span className="text-[10px] text-zinc-500">{q.size}</span>
                        </button>
                      ))}
                    </div>
                  </>
                )}
              </div>

              <button className="flex-1 h-11 bg-[#1c1a27] hover:bg-[#232031] border border-white/5 transition-colors rounded-xl flex items-center justify-center gap-2 text-sm font-bold text-zinc-200 cursor-pointer">
                <Share2 className="w-4 h-4 text-zinc-400" /> Share
              </button>

              <button 
                onClick={() => setIsLiked(!isLiked)}
                className={`flex-1 h-11 transition-colors rounded-xl flex items-center justify-center gap-2 text-sm font-bold cursor-pointer ${
                  isLiked ? "bg-[#8c1cff] text-white shadow-[0_5px_15px_rgba(140,28,255,0.35)]" : "bg-[#1c1a27] text-zinc-200 hover:bg-[#232031] border border-white/5"
                }`}
              >
                <Heart className={`w-4 h-4 ${isLiked ? "fill-white text-white" : "text-zinc-400"}`} /> Liked
              </button>
            </div>

            <div className="space-y-3.5 text-base font-semibold text-zinc-100 pt-1">
              <div className="flex items-center gap-3"><Eye className="w-5 h-5 text-zinc-400" /> 125,908 views</div>
              <div className="flex items-center gap-3"><Heart className="w-5 h-5 fill-red-500 text-red-500" /> 47,987 likes</div>
              <div className="flex items-center gap-3"><LineChart className="w-5 h-5 text-zinc-400" /> 1,938,394 streaming</div>
              <div className="flex items-center gap-3"><Bell className="w-5 h-5 text-zinc-400" /> Start 2 hours ago</div>
            </div>
          </div>
        </div>
      </div>

      {/* ============ RIGHT COLUMN: CHAT + RELATED ============ */}
      <div className="lg:col-span-4 flex flex-col gap-8 w-full max-w-[420px] mx-auto xl:mx-0">
        
        {/* Live Chat Pane */}
        <div className="w-full bg-[#181628] rounded-3xl border border-white/5 flex flex-col p-6 shadow-xl relative">
          <div className="flex items-center justify-between mb-6 pb-2">
            <h3 className="font-bold text-base text-white">Live Chat</h3>
            <span className="flex items-center gap-2 text-[11px] font-bold text-[#797a8e]">
              <Users className="w-4 h-4" /> 15,986 people
            </span>
          </div>

          <div className="space-y-6 max-h-[300px] overflow-y-auto pr-2 scrollbar-none flex-1 mb-4">
            {chatMessages.map((user) => (
              <div key={user.id} className="flex gap-4">
                <div className="relative shrink-0">
                  <div className={`w-9 h-9 rounded-full bg-gradient-to-tr ${user.avatar} font-bold text-xs flex items-center justify-center text-white border border-[#1e1c2a]`}>
                    {user.user.charAt(0)}
                  </div>
                  {user.check && (
                    <div className="absolute -bottom-1 -right-1 bg-blue-500 w-3.5 h-3.5 rounded-full flex items-center justify-center border-2 border-[#1c1a27]">
                      <CheckCircle2 className="w-2.5 h-2.5 text-white" />
                    </div>
                  )}
                </div>
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-sm font-bold text-white">
                    {user.user} 
                    {user.online ? <div className="w-2 h-2 bg-[#1bc285] rounded-full" /> : <div className="w-2 h-2 bg-[#fc5b69] rounded-full" />}
                  </div>
                  <p className="text-sm leading-relaxed text-zinc-100">{user.text}</p>
                </div>
              </div>
            ))}
          </div>

          <form onSubmit={handleSendMessage} className="relative flex items-center h-12 w-full mt-2">
            <input 
              type="text" 
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              placeholder="Write your message..." 
              className="w-full h-full rounded-2xl bg-[#14121d] border border-transparent pl-12 pr-12 text-sm font-medium text-white placeholder-zinc-400 focus:outline-none focus:border-[#8c1cff]/50"
            />
            <MoreHorizontal className="absolute left-4 w-4 h-4 text-zinc-500" />
            <button type="submit" className="absolute right-1 w-10 h-10 rounded-xl bg-[#8c1cff] flex items-center justify-center shadow-lg transition-transform hover:scale-105 hover:bg-[#7818e3] cursor-pointer">
              <Send className="w-3.5 h-3.5 text-white mr-0.5" />
            </button>
          </form>
        </div>

        {/* Related Videos */}
        <div className="space-y-4 w-full">
          <h3 className="font-bold text-base text-white pl-2">Related Videos</h3>
          <div className="space-y-4">
            {[
              { id: 2, title: "Prepare for your first skateboard jump", author: "Min Mahar", handle: "minmahar", views: "125,908 views", time: "2 days ago", bg: "from-zinc-500 to-slate-700" },
              { id: 3, title: "Tips to playing skateboard on the ramp", author: "Fintech MM", handle: "fintech_mm", views: "125,908 views", time: "2 days ago", bg: "from-amber-600 to-amber-900" }
            ].map((v, i) => (
              <div key={i} className="flex gap-4 p-1 hover:bg-white/5 transition-colors rounded-xl cursor-pointer group">
                <Link href={`/watch/${v.id}`} className={`w-32 h-[76px] rounded-[18px] bg-gradient-to-tr ${v.bg} border border-white/5 flex items-center justify-center shrink-0`} />
                
                <div className="flex flex-col py-0.5 pr-2 flex-1">
                  <Link href={`/watch/${v.id}`}>
                    <h4 className="text-base font-bold text-white group-hover:text-[#a042ff] transition-colors leading-snug line-clamp-2">
                      {v.title}
                    </h4>
                  </Link>

                  <Link href={`/channel/${v.handle}`} className="text-sm font-semibold text-zinc-200 hover:text-white mt-1.5 transition-colors w-max">
                    {v.author}
                  </Link>
                  <p className="text-xs sm:text-sm text-zinc-400 mt-1 font-medium">{v.views} • {v.time}</p>
                </div>
              </div>
            ))}
          </div>
          <button className="w-full h-11 bg-[#8c1cff] hover:bg-[#7a14e6] text-white rounded-[16px] text-xs font-bold transition-all shadow-[0_5px_15px_rgba(140,28,255,0.3)] mt-2 cursor-pointer">
            See All related videos (32)
          </button>
        </div>

      </div>
    </div>
  );
}