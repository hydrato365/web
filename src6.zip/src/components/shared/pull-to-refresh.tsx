"use client";

import React, { useState, useRef } from "react";
import { RefreshCw } from "lucide-react";
import { useRouter } from "next/navigation";

export function PullToRefresh({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const [pullDistance, setPullDistance] = useState(0);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isDragging, setIsDragging] = useState(false);

  const startY = useRef(0);
  const startX = useRef(0);
  const isPulling = useRef(false);
  const gestureLocked = useRef<"horizontal" | "vertical" | null>(null);
  const containerRef = useRef<HTMLElement>(null);

  const PULL_THRESHOLD = 70;
  const MAX_PULL = 140;

  const onTouchStart = (e: React.TouchEvent) => {
    if (isRefreshing) return;
    
    const scrollTop = containerRef.current?.scrollTop || 0;
    if (scrollTop <= 0) {
      startY.current = e.touches[0].clientY;
      startX.current = e.touches[0].clientX;
      isPulling.current = true;
      gestureLocked.current = null;
      setIsDragging(false);
    }
  };

  const onTouchMove = (e: React.TouchEvent) => {
    if (!isPulling.current || isRefreshing) return;
    
    const touch = e.touches[0];
    const diffX = Math.abs(touch.clientX - startX.current);
    const diffY = touch.clientY - startY.current;

    // ၁။ စစချင်းတွင် ဘယ်ညာဆွဲနေတာလား၊ အောက်ဆွဲနေတာလားကို ဦးတည်ချက် သော့ခတ် (Direction Lock) မှတ်သားမည်
    if (!gestureLocked.current) {
      if (diffX > 8 || Math.abs(diffY) > 8) {
        if (diffX > Math.abs(diffY)) {
          // ဘယ်ညာ ဆွဲနေသည် (Chips များ ရွှေ့နေသည်) -> Pull ကို ရပ်ဆိုင်းမည်
          gestureLocked.current = "horizontal";
          isPulling.current = false;
          return;
        } else if (diffY > 0) {
          // အောက်ဆွဲနေသည် -> ဒေါင်လိုက် ဆွဲချခြင်းအဖြစ် သတ်မှတ်မည်
          gestureLocked.current = "vertical";
          setIsDragging(true);
        } else {
          isPulling.current = false;
          return;
        }
      }
      return;
    }

    if (gestureLocked.current !== "vertical") return;

    // ၂။ လက်ချောင်း အောက်ဆင်းဆင်း၊ အပေါ်ပြန်တက်တက် လက်ရွေ့သည့်နှုန်းအတိုင်း အတိအကျ ချောမွေ့စွာ လိုက်ပါစေမည်
    if (diffY > 0) {
      const resistantDistance = Math.min(diffY * 0.4, MAX_PULL);
      setPullDistance(resistantDistance);
      // ဆွဲနေစဉ် Scroll ခုန်မသွားစေရန် scrollTop အား ၀ တွင် ထိန်းထားမည်
      if (containerRef.current) {
        containerRef.current.scrollTop = 0;
      }
    } else {
      // လက်ချောင်း အစမှတ်ထက် ကျော်လွန်၍ အပေါ်ရောက်သွားပါက ၀ သို့ ညင်သာစွာ ကပ်မည်
      setPullDistance(0);
    }
  };

  const onTouchEnd = () => {
    if (!isPulling.current && gestureLocked.current !== "vertical") {
      isPulling.current = false;
      gestureLocked.current = null;
      setIsDragging(false);
      return;
    }

    isPulling.current = false;
    gestureLocked.current = null;
    setIsDragging(false);

    if (pullDistance >= PULL_THRESHOLD) {
      setIsRefreshing(true);
      setPullDistance(PULL_THRESHOLD);
      
      setTimeout(() => {
        setIsRefreshing(false);
        setPullDistance(0);
        router.refresh();
      }, 800);
    } else {
      // မပြည့်ဘဲ လွှတ်လိုက်ပါက သို့မဟုတ် လက်ချောင်းကို အပေါ်ပြန်တွန်းတင်ပြီးမှ လွှတ်လိုက်ပါက ၀ သို့ ညင်သာစွာ ပြန်ဆင်းသွားမည်
      setPullDistance(0);
    }
  };

  const onTouchCancel = () => {
    isPulling.current = false;
    gestureLocked.current = null;
    setIsDragging(false);
    setPullDistance(0);
  };

  return (
    <main
      id="main-scroll-area"
      ref={containerRef}
      onTouchStart={onTouchStart}
      onTouchMove={onTouchMove}
      onTouchEnd={onTouchEnd}
      onTouchCancel={onTouchCancel}
      className="flex-1 overflow-y-auto overscroll-y-none pt-16 md:pt-0 pb-16 md:pb-0 relative"
      style={{ WebkitOverflowScrolling: "touch" }}
    >
      {/* 🔄 Refresh Spinner: တကယ် ဆွဲချနေချိန်မှသာ ပေါ်မည် */}
      {pullDistance > 0 && (
        <div
          className="absolute left-0 right-0 flex justify-center items-center z-50 pointer-events-none"
          style={{
            top: "-40px",
            transform: `translateY(${pullDistance}px)`,
            opacity: pullDistance > 10 ? Math.min(pullDistance / PULL_THRESHOLD, 1) : 0,
            transition: isDragging ? "none" : "transform 0.3s ease-out, opacity 0.3s ease-out",
          }}
        >
          <div className="w-8 h-8 rounded-full bg-[#232130] border border-white/10 flex items-center justify-center shadow-[0_4px_12px_rgba(0,0,0,0.5)]">
            <RefreshCw
              className={`w-4 h-4 text-zinc-300 ${isRefreshing ? "animate-spin" : ""}`}
              style={{
                transform: isRefreshing ? "none" : `rotate(${pullDistance * 3}deg)`,
              }}
            />
          </div>
        </div>
      )}

      {/* 📄 Actual Page Content: ဆွဲနေချိန် မဟုတ်လျှင် transform လုံးဝ မထည့်ဘဲ မူလအတိုင်း ထားမည် */}
      <div
        className="min-h-full"
        style={
          pullDistance > 0
            ? {
                transform: `translateY(${pullDistance}px)`,
                transition: isDragging ? "none" : "transform 0.3s ease-out",
              }
            : undefined
        }
      >
        {children}
      </div>
    </main>
  );
}