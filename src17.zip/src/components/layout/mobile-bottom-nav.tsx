"use client";

import React, { useEffect, useState, useRef } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { layoutConfig } from "@/lib/layout-config";
import { NavIcon } from "@/components/layout/nav-icon";

const navItems = [
  { href: "/", label: "Home", icon: "home" },
  { href: "/search", label: "Search", icon: "search" },
  { href: "/subscriptions", label: "Tuned", icon: "tuned" },
  { href: "/messages", label: "Messages", icon: "messages" },
  { href: "/profile", label: "Profile", isAvatar: true },
];

export function MobileBottomNav() {
  const pathname = usePathname();
  const [isScrollingDown, setIsScrollingDown] = useState(false);
  const lastScrollY = useRef(0);

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      if (currentScrollY <= 15) {
        setIsScrollingDown(false);
        lastScrollY.current = currentScrollY;
        return;
      }
      if (Math.abs(currentScrollY - lastScrollY.current) < 10) return;
      setIsScrollingDown(currentScrollY > lastScrollY.current);
      lastScrollY.current = currentScrollY;
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  if (layoutConfig.shouldHide(pathname, layoutConfig.hideMobileBottomNavRoutes)) {
    return null;
  }

  return (
    <nav 
      style={{ transform: isScrollingDown ? "translate3d(0, 100%, 0)" : "translateZ(0)" }}
      className={`md:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#131224]/95 backdrop-blur-xl flex items-center justify-around py-2 px-1 transition-transform duration-300 ease-in-out`}
    >
      {navItems.map((item) => {
        const isActive = pathname === item.href;
        
        if (item.isAvatar) {
          return (
            <Link
              key="you"
              href={item.href}
              className={`flex flex-col items-center justify-center gap-1 py-1 px-2.5 rounded-xl transition-colors cursor-pointer ${
                isActive ? "text-[#a042ff]" : "text-zinc-400 hover:text-white"
              }`}
            >
              <div className={`w-6 h-6 rounded-full bg-red-600 flex items-center justify-center font-bold text-white text-xs transition-all ${isActive ? "border-2 border-[#a042ff] scale-110 shadow-[0_0_8px_#a042ff]" : "border border-white/20"}`}>
                T
              </div>
              <span className={`text-[10px] tracking-tight ${isActive ? "font-bold text-white" : "font-medium text-zinc-400"}`}>
                {item.label}
              </span>
            </Link>
          );
        }

        return (
          <Link
            key={item.href}
            href={item.href}
            className={`flex flex-col items-center justify-center gap-1 py-1 px-2.5 rounded-xl transition-colors ${
              isActive ? "text-[#a042ff]" : "text-zinc-400 hover:text-white"
            }`}
          >
            <NavIcon name={item.icon as any} isActive={isActive} className={`w-5 h-5 ${isActive ? "text-[#a042ff]" : "text-zinc-400"}`} />
            <span className={`text-[10px] tracking-tight ${isActive ? "font-bold text-white" : "font-medium text-zinc-400"}`}>
              {item.label}
            </span>
          </Link>
        );
      })}
    </nav>
  );
}