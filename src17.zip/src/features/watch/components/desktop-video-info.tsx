"use client";

import React from "react";
import Link from "next/link";
import { CheckCircle2, ThumbsUp, Star, Share2, Bookmark, Download } from "lucide-react";

interface DesktopVideoInfoProps {
  videoData: {
    title: string;
    views: number;
    description?: string;
    created_at?: string;
  } | null;
  isLiked: boolean;
  setIsLiked: (val: boolean) => void;
  isDownloadOpen: boolean;
  setIsDownloadOpen: (val: boolean) => void;
  downloadProgress: string | null;
}

export function DesktopVideoInfo({
  videoData,
  isLiked,
  setIsLiked,
  isDownloadOpen,
  setIsDownloadOpen,
  downloadProgress,
}: DesktopVideoInfoProps) {
  return (
    <>
      <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white leading-snug">
        {videoData?.title || "Loading video..."}
      </h1>

      <div className="flex flex-wrap items-center justify-between gap-4 pb-1">
        <div className="flex items-center gap-3">
          <Link href="/channel/minmahar" className="shrink-0 cursor-pointer">
            <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-amber-700 to-amber-900 border border-zinc-700 flex items-center justify-center font-bold text-white text-sm">
              M
            </div>
          </Link>
          <div className="flex flex-col">
            <Link href="/channel/minmahar" className="font-bold text-white hover:underline flex items-center gap-1.5 text-sm">
              Min Mahar
              <CheckCircle2 className="w-3.5 h-3.5 text-blue-500 fill-blue-500 text-[#131224]" />
            </Link>
            <span className="text-xs text-zinc-400">1.98M Tuned</span>
          </div>
          <button className="ml-2 h-9 px-4 rounded-xl bg-white hover:bg-zinc-200 text-zinc-950 font-bold text-xs uppercase tracking-wider transition-colors cursor-pointer">
            + Tune
          </button>
        </div>

        <div className="flex items-center gap-2">
          <button 
            onClick={() => setIsLiked(!isLiked)}
            className={`h-9 px-4 rounded-xl border text-xs font-semibold flex items-center gap-2 transition-colors cursor-pointer ${
              isLiked 
                ? "bg-[#8c1cff] text-white border-[#8c1cff]" 
                : "bg-[#141320] border-zinc-800 text-zinc-200 hover:bg-zinc-800"
            }`}
          >
            <ThumbsUp className={`w-3.5 h-3.5 ${isLiked ? "fill-white" : ""}`} />
            <span>47K</span>
          </button>

          <Link
            href="/stars"
            className="h-9 px-4 rounded-xl border border-amber-500/30 bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Star className="w-3.5 h-3.5 fill-amber-400" />
            <span>Send Star</span>
          </Link>

          <button className="h-9 px-3.5 rounded-xl border border-zinc-800 bg-[#141320] hover:bg-zinc-800 text-zinc-200 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer">
            <Share2 className="w-3.5 h-3.5 text-zinc-400" />
            <span>Share</span>
          </button>

          <button className="h-9 px-3.5 rounded-xl border border-zinc-800 bg-[#141320] hover:bg-zinc-800 text-zinc-200 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer">
            <Bookmark className="w-3.5 h-3.5 text-zinc-400" />
            <span>Save</span>
          </button>

          <button 
            onClick={() => setIsDownloadOpen(!isDownloadOpen)}
            className="h-9 px-3.5 rounded-xl border border-zinc-800 bg-[#141320] hover:bg-zinc-800 text-zinc-200 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-zinc-400" />
            <span>{downloadProgress ? `DL (${downloadProgress})` : "Download"}</span>
          </button>
        </div>
      </div>

      <div className="p-4 bg-[#141320] border border-zinc-800 rounded-2xl text-xs text-zinc-300 space-y-2 leading-relaxed">
        <div className="flex items-center gap-3 font-bold text-white text-xs">
          <span>{(videoData?.views || 0).toLocaleString()} views</span>
          <span>•</span>
          <span>{videoData?.created_at ? new Date(videoData.created_at).toLocaleDateString() : "Recently uploaded"}</span>
        </div>
        <p className="text-zinc-400 leading-relaxed">
          {videoData?.description || "No description provided."}
        </p>
      </div>
    </>
  );
}