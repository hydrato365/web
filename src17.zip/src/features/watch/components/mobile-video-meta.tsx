"use client";

import React from "react";
import Link from "next/link";
import { CheckCircle2, ThumbsUp, Star, Share2, Bookmark } from "lucide-react";

interface MobileVideoMetaProps {
  videoData: {
    title: string;
    views: number;
    description?: string;
    created_at?: string;
  } | null;
  isLiked: boolean;
  setIsLiked: (val: boolean) => void;
}

export function MobileVideoMeta({ videoData, isLiked, setIsLiked }: MobileVideoMetaProps) {
  return (
    <div className="flex flex-col px-3 pt-3 pb-1">
      <h1 className="text-[15px] sm:text-base font-bold leading-snug text-white line-clamp-2">
        {videoData?.title || "Loading video..."}
      </h1>

      <div className="flex items-center gap-1.5 text-[11px] text-zinc-400 font-medium mt-1">
        <span>{(videoData?.views || 0).toLocaleString()} views</span>
        <span>•</span>
        <span>{videoData?.created_at ? new Date(videoData.created_at).toLocaleDateString() : "Recently uploaded"}</span>
      </div>

      <div className="mt-3 flex items-center justify-between gap-3">
        <Link href="/channel/minmahar" className="flex items-center gap-2.5 min-w-0 flex-1">
          <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-amber-600 to-amber-900 border border-white/10 flex items-center justify-center font-bold text-white text-xs shrink-0">
            M
          </div>
          <div className="flex flex-col min-w-0">
            <div className="flex items-center gap-1">
              <span className="text-sm font-bold text-white truncate">
                Min Mahar
              </span>
              <CheckCircle2 className="w-3.5 h-3.5 text-blue-500 fill-blue-500 text-[#131224] shrink-0" />
            </div>
            <span className="text-[10px] text-zinc-400">1.98M Tuned</span>
          </div>
        </Link>

        <button className="h-8 px-4 bg-white text-zinc-950 text-xs font-bold rounded-full shrink-0 active:scale-95 transition-transform shadow-sm">
          + Tune
        </button>
      </div>

      <div className="mt-3 flex items-center gap-2 overflow-x-auto scrollbar-none -mx-3 px-3 pb-1">
        <button 
          onClick={() => setIsLiked(!isLiked)} 
          className={`h-8 px-4 shrink-0 rounded-full flex items-center gap-1.5 text-xs font-bold transition-all ${
            isLiked 
              ? "bg-[#8c1cff] text-white shadow-md shadow-[#8c1cff]/30" 
              : "bg-[#232130] text-zinc-200 hover:bg-[#2c2a3b]"
          }`}
        >
          <ThumbsUp className={`w-3.5 h-3.5 ${isLiked ? "fill-white" : ""}`} /> 
          <span>{isLiked ? "47K" : "47K"}</span>
        </button>

        <Link 
          href="/stars" 
          className="h-8 px-4 shrink-0 bg-amber-500/10 border border-amber-500/20 text-amber-400 hover:bg-amber-500/20 rounded-full flex items-center gap-1.5 text-xs font-bold transition-all shadow-sm"
        >
          <Star className="w-3.5 h-3.5 fill-amber-400" /> 
          <span>Star</span>
        </Link>

        <button className="h-8 px-4 shrink-0 bg-[#232130] hover:bg-[#2c2a3b] text-zinc-200 rounded-full flex items-center gap-1.5 text-xs font-bold transition-colors">
          <Share2 className="w-3.5 h-3.5 text-zinc-400" /> 
          <span>Share</span>
        </button>

        <button className="h-8 px-4 shrink-0 bg-[#232130] hover:bg-[#2c2a3b] text-zinc-200 rounded-full flex items-center gap-1.5 text-xs font-bold transition-colors">
          <Bookmark className="w-3.5 h-3.5 text-zinc-400" /> 
          <span>Save</span>
        </button>
      </div>
    </div>
  );
}