"use client";

import React, { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { 
  Home, 
  Users, 
  Bookmark, 
  Download, 
  History, 
  ChevronDown 
} from "lucide-react";

const followedChannels = [
  { id: 1, name: "Min Mahar", handle: "minmahar", avatar: "from-amber-600 to-amber-900", isLive: true },
  { id: 2, name: "Fintech MM", handle: "fintech_mm", avatar: "from-blue-600 to-blue-800", isLive: true },
  { id: 3, name: "Comic Hub", handle: "comic_hub", avatar: "from-emerald-600 to-teal-800", isLive: false },
  { id: 4, name: "Book Tube MM", handle: "book_tube", avatar: "from-purple-600 to-indigo-800", isLive: false },
  { id: 5, name: "Khit Tech", handle: "khit_tech", avatar: "from-red-600 to-rose-900", isLive: false },
  { id: 6, name: "Gamer MM", handle: "gamer_mm", avatar: "from-orange-600 to-amber-800", isLive: false },
];

const toolItems = [
  { href: "/saved", label: "Saved", icon: Bookmark },
  { href: "/downloads", label: "Downloads", icon: Download },
  { href: "/history", label: "History", icon: History },
];

export function Sidebar() {
  const pathname = usePathname();
  const [isSubOpen, setIsSubOpen] = useState(true);
  const [isLoadingChannels, setIsLoadingChannels] = useState(true);

  useEffect(() => {
    // ၂.၅ စက္ကန့်အကြာမှ Data တက်လာသယောင် Fake လုပ်မည်
    const timer = setTimeout(() => setIsLoadingChannels(false), 2500);
    return () => clearTimeout(timer);
  }, []);

  return (
    <>
      <aside className="hidden md:flex w-20 bg-[#131224] border-r border-white/5 flex-col items-center py-6 h-screen shrink-0 z-50 relative select-none">
      
      {/* ၁။ Logo */}
      <Link 
        href="/" 
        title="Khit Home"
        className="flex items-center justify-center gap-0.5 mb-4 hover:scale-105 transition-transform shrink-0"
      >
        <svg className="w-8 h-8" viewBox="125 120 285 270" fill="none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="primaryGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#00F2FE"/>
              <stop offset="50%" stopColor="#4FACFE"/>
              <stop offset="100%" stopColor="#7F00FF"/>
            </linearGradient>
            <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
              <feDropShadow dx="0" dy="4" stdDeviation="10" floodColor="#00F2FE" floodOpacity="0.4"/>
            </filter>
          </defs>
          <g filter="url(#glow)">
            <rect x="140" y="136" width="52" height="240" rx="18" fill="url(#primaryGrad)"/>
            <path d="M 230 256 L 360 160 C 375 148 395 158 395 178 L 395 334 C 395 354 375 364 360 352 Z" fill="url(#primaryGrad)"/>
            <circle cx="218" cy="256" r="14" fill="#131224"/>
          </g>
        </svg>
        <span className="text-lg font-black tracking-tight text-white leading-none">
          hit
        </span>
      </Link>

      {/* ၂။ အပေါ်ပိုင်း အသေခလုတ်များ (Home & Subscriptions) */}
      <div className="flex flex-col items-center gap-1 w-full shrink-0">
        {/* Home */}
        <Link 
          href="/" 
          title="Home"
          className="relative group w-full flex justify-center shrink-0 px-1"
        >
          {pathname === "/" && (
            <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1.5 h-6 rounded-r-full bg-[#8c1cff] shadow-[0_0_12px_#8c1cff]" />
          )}
          <div className={`w-[72px] py-2 rounded-2xl transition-all duration-200 flex flex-col items-center justify-center gap-1 hover:scale-105 active:scale-95 ${
            pathname === "/" ? "text-white" : "text-zinc-400 hover:text-white"
          }`}>
            <Home className={`w-5 h-5 transition-all duration-200 ${pathname === "/" ? "text-[#a042ff]" : "text-zinc-400 group-hover:text-white group-hover:scale-110"}`} />
            <span className="text-[11px] font-bold text-center tracking-tight leading-tight px-0.5">
              Home
            </span>
          </div>
        </Link>

        {/* Subscriptions with Dropdown Toggle */}
        <div className="relative group w-full flex flex-col items-center shrink-0 px-1">
          {pathname === "/subscriptions" && (
            <div className="absolute left-0 top-3 w-1.5 h-6 rounded-r-full bg-[#8c1cff] shadow-[0_0_12px_#8c1cff]" />
          )}
          <Link
            href="/subscriptions"
            title="Subscriptions Feed"
            className={`w-[72px] pt-2 pb-0.5 rounded-t-2xl transition-all duration-200 flex flex-col items-center justify-center gap-1 hover:scale-105 active:scale-95 ${
              pathname === "/subscriptions" ? "text-white" : "text-zinc-400 hover:text-white"
            }`}
          >
            <Users className={`w-5 h-5 transition-all duration-200 ${pathname === "/subscriptions" ? "text-[#a042ff]" : "text-zinc-400 group-hover:text-white group-hover:scale-110"}`} />
            <span className="text-[11px] font-bold text-center tracking-tight leading-tight px-0.5">
              Subscriptions
            </span>
          </Link>
          <button
            onClick={() => setIsSubOpen(!isSubOpen)}
            title={isSubOpen ? "Collapse Channels" : "Expand Channels"}
            className="w-[72px] py-0.5 flex items-center justify-center text-zinc-500 hover:text-white transition-colors cursor-pointer"
          >
            <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 ${isSubOpen ? "rotate-180 text-[#a042ff]" : ""}`} />
          </button>
        </div>
      </div>

      {/* ၃။ အလယ်ပိုင်း Scroll လုပ်နိုင်သော Channels စာရင်း (Live Indicator ပါဝင်သည်) */}
      {isSubOpen && (
        <div className="flex-1 w-full flex flex-col items-center gap-3 py-3 overflow-y-auto scrollbar-none min-h-0">
          {isLoadingChannels ? (
            /* Loading Skeletons (Data မရောက်ခင် အဝိုင်းလေးများ Shimmer ပြမည်) */
            [...Array(5)].map((_, i) => (
              <div key={i} className="w-9 h-9 rounded-full bg-[#1c1a30] animate-pulse border border-white/5 shrink-0" />
            ))
          ) : (
            /* Data ရောက်လာလျှင် Animations ဖြင့် လှလှပပ ပေါ်လာမည် */
            followedChannels.map((channel, index) => (
              <Link
                key={channel.id}
                href={`/channel/${channel.handle}`}
                title={`${channel.name}${channel.isLive ? " (LIVE NOW)" : ""}`}
                className="relative group shrink-0 hover:scale-110 transition-transform animate-in fade-in zoom-in-95 duration-500"
                style={{ animationDelay: `${index * 75}ms`, animationFillMode: "both" }}
              >
                <div className={`w-9 h-9 rounded-full bg-gradient-to-tr ${channel.avatar} flex items-center justify-center font-bold text-xs text-white border transition-all ${
                  channel.isLive 
                    ? "border-red-500 shadow-[0_0_10px_rgba(239,68,68,0.5)]" 
                    : "border-white/10 group-hover:border-white/30"
                }`}>
                  {channel.name.charAt(0)}
                </div>
                {channel.isLive && (
                  <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-[#131224] animate-pulse" />
                )}
              </Link>
            ))
          )}
        </div>
      )}

      {/* ၄။ အောက်ဆုံး အသေ Tool ခလုတ်များ (Saved, Downloads, History) */}
      <div className="pt-3 border-t border-white/5 flex flex-col w-full items-center shrink-0 mt-auto px-1 gap-1">
        {toolItems.map((item) => {
          const Icon = item.icon;
          const isActive = pathname === item.href;
          return (
            <Link 
              key={item.href}
              href={item.href} 
              title={item.label}
              className="relative group w-full flex justify-center shrink-0"
            >
              {isActive && (
                <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1.5 h-6 rounded-r-full bg-[#8c1cff] shadow-[0_0_12px_#8c1cff]" />
              )}
              
              <div className={`w-[72px] py-2 rounded-2xl transition-all duration-200 flex flex-col items-center justify-center gap-1 hover:scale-110 active:scale-95 ${
                isActive 
                  ? "text-white" 
                  : "text-zinc-400 hover:text-white"
              }`}>
                <Icon className={`w-5 h-5 transition-all duration-200 ${isActive ? "text-[#a042ff]" : "text-zinc-400 group-hover:text-white group-hover:scale-110"}`} />
                <span className="text-[11px] font-bold text-center tracking-tight leading-tight px-0.5">
                  {item.label}
                </span>
              </div>
            </Link>
          );
        })}
      </div>

    </aside>

    {/* 📱 Mobile Bottom Navigation Bar (ဖုန်း View တွင် အောက်ခြေတွင် ကပ်လျက် ပေါ်မည့် Bar) */}
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-[#131224]/95 backdrop-blur-xl border-t border-white/10 flex items-center justify-around py-2 px-1">
      {[
        { href: "/", label: "Home", icon: Home },
        { href: "/subscriptions", label: "Subscriptions", icon: Users },
        ...toolItems,
      ].map((item) => {
        const Icon = item.icon;
        const isActive = pathname === item.href;
        return (
          <Link
            key={item.href}
            href={item.href}
            className={`flex flex-col items-center justify-center gap-1 py-1 px-2.5 rounded-xl transition-colors ${
              isActive ? "text-[#a042ff]" : "text-zinc-400 hover:text-white"
            }`}
          >
            <Icon className={`w-5 h-5 ${isActive ? "text-[#a042ff]" : "text-zinc-400"}`} />
            <span className={`text-[10px] tracking-tight ${isActive ? "font-bold text-white" : "font-medium text-zinc-400"}`}>
              {item.label}
            </span>
          </Link>
        );
      })}
    </nav>
    </>
  );
}