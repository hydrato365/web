"use client";

import React, { useState } from "react";
import Link from "next/link";
import { 
  Bookmark, 
  BookmarkCheck, 
  Play, 
  Shuffle, 
  Trash2, 
  Clock, 
  Lock, 
  Sparkles, 
  Eye, 
  CheckCircle2, 
  Share2, 
  SlidersHorizontal 
} from "lucide-react";
import { Button } from "@/components/ui/button";

// Mock Saved Videos Data
const initialSavedVideos = [
  {
    id: 1,
    title: "Oppenheimer Full Movie Recap - The Father of the Atomic Bomb",
    creator: "Min Mahar",
    handle: "minmahar",
    views: "125K",
    duration: "38:20",
    addedDate: "Saved 2 days ago",
    category: "Movie Recap",
    thumbBg: "from-amber-950/60 to-zinc-950",
  },
  {
    id: 3,
    title: "Solo Leveling: Ragnarok Episodes 1 to 15 (Motion Comic Recap)",
    creator: "Comic Hub",
    handle: "comic_hub",
    views: "89K",
    duration: "29:40",
    addedDate: "Saved 3 days ago",
    category: "Comic & Manga",
    thumbBg: "from-emerald-950/60 to-zinc-950",
  },
  {
    id: 4,
    title: "The Art of War by Sun Tzu (Full Audiobook with Myanmar Explanation)",
    creator: "Book Tube MM",
    handle: "book_tube",
    views: "61K",
    duration: "45:10",
    addedDate: "Saved 1 week ago",
    category: "Audiobooks",
    thumbBg: "from-purple-950/60 to-zinc-950",
  },
  {
    id: 5,
    title: "Cybersecurity Essentials for Myanmar Remote Workers & Devs",
    creator: "Khit Tech",
    handle: "khit_tech",
    views: "32K",
    duration: "18:25",
    addedDate: "Saved 2 weeks ago",
    category: "Tech & Coding",
    thumbBg: "from-red-950/60 to-zinc-950",
  },
];

export default function SavedVideosPage() {
  const [savedVideos, setSavedVideos] = useState(initialSavedVideos);
  const [searchQuery, setSearchQuery] = useState("");

  // Remove video from saved list
  const handleRemoveSaved = (id: number) => {
    setSavedVideos(savedVideos.filter((v) => v.id !== id));
  };

  // Clear all saved videos
  const handleClearAll = () => {
    setSavedVideos([]);
  };

  const filteredVideos = savedVideos.filter((v) =>
    v.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    v.creator.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="px-4 sm:px-8 pb-16 pt-4 max-w-[1400px] mx-auto space-y-8 relative z-10 animate-in fade-in duration-300">
      
      {/* ================= ၁။ SAVED PLAYLIST HERO SUMMARY ================= */}
      <div className="rounded-3xl bg-gradient-to-r from-[#1c1a27] via-[#181624] to-[#14121d] border border-white/5 p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        
        {/* Background Ambient Glow */}
        <div className="absolute top-0 right-0 w-80 h-80 bg-red-600/10 blur-[90px] rounded-full pointer-events-none" />

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          
          {/* Left: Info */}
          <div className="space-y-3">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-600/10 border border-red-600/20 text-[#fc5b69] text-xs font-bold uppercase tracking-wider">
              <Lock className="w-3.5 h-3.5" />
              <span>Private Playlist</span>
            </div>

            <h1 className="text-2xl sm:text-4xl font-black text-white tracking-tight flex items-center gap-3">
              <Bookmark className="w-8 h-8 text-[#fc5b69] fill-[#fc5b69]" />
              Saved Videos
            </h1>

            <div className="flex flex-wrap items-center gap-3 text-xs sm:text-sm text-[#797a8e] font-medium">
              <span className="text-zinc-200 font-bold">{savedVideos.length} Videos</span>
              <span>•</span>
              <span>Updated recently</span>
              <span>•</span>
              <span>Only visible to you</span>
            </div>
          </div>

          {/* Right: Actions (Play All, Shuffle, Clear) */}
          {savedVideos.length > 0 && (
            <div className="flex flex-wrap items-center gap-3 shrink-0">
              {/* Play All Link */}
              <Link
                href={`/watch/${savedVideos[0]?.id || 1}`}
                className="h-11 px-6 bg-[#fc5b69] hover:bg-[#ff6976] text-white font-black text-xs sm:text-sm rounded-2xl flex items-center gap-2 shadow-[0_5px_20px_rgba(252,91,105,0.3)] transition-all cursor-pointer"
              >
                <Play className="w-4 h-4 fill-white" />
                <span>Play All</span>
              </Link>

              {/* Shuffle Button */}
              <button
                title="Shuffle playlist"
                className="h-11 w-11 rounded-2xl bg-[#1c1a27] hover:bg-zinc-800 border border-white/5 text-zinc-300 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
              >
                <Shuffle className="w-4 h-4" />
              </button>

              {/* Clear All Button */}
              <button
                onClick={handleClearAll}
                title="Clear all saved videos"
                className="h-11 px-4 rounded-2xl bg-red-600/10 hover:bg-red-600/20 border border-red-600/30 text-red-400 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Clear</span>
              </button>
            </div>
          )}

        </div>
      </div>

      {/* ================= ၂။ FILTER & SEARCH BAR ================= */}
      {savedVideos.length > 0 && (
        <div className="flex items-center justify-between gap-4">
          <div className="relative w-full max-w-xs">
            <input
              type="text"
              placeholder="Search in saved videos..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full h-10 bg-[#1c1a27] border border-white/5 rounded-2xl px-4 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-[#fc5b69]/50 transition-colors"
            />
          </div>

          <span className="text-xs font-semibold text-zinc-400">
            Showing {filteredVideos.length} of {savedVideos.length}
          </span>
        </div>
      )}

      {/* ================= ၃။ SAVED VIDEOS LIST ================= */}
      {savedVideos.length === 0 ? (
        /* Empty State */
        <div className="py-24 text-center rounded-3xl bg-[#1c1a27]/50 border border-white/5 space-y-3">
          <Bookmark className="w-12 h-12 text-zinc-600 mx-auto" />
          <h3 className="text-base font-bold text-white">No saved videos yet</h3>
          <p className="text-xs text-[#797a8e] max-w-sm mx-auto leading-relaxed">
            Bookmark your favorite streams, recaps, and audiobooks to watch them anytime.
          </p>
          <div className="pt-2">
            <Link
              href="/"
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-xs shadow-lg transition-colors"
            >
              Explore Videos
            </Link>
          </div>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredVideos.map((video, index) => (
            <div
              key={video.id}
              className="group flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between py-2 border-b border-white/5 last:border-b-0 transition-colors"
            >
              {/* Left Side: Index & Video Info */}
              <div className="flex gap-4 items-start flex-1 overflow-hidden">
                
                {/* Index Number */}
                <span className="text-xs font-bold text-zinc-500 self-center hidden sm:block w-5 text-center">
                  {index + 1}
                </span>

                {/* Thumbnail */}
                <Link
                  href={`/watch/${video.id}`}
                  className={`relative w-44 sm:w-56 aspect-[16/9] rounded-xl bg-gradient-to-tr ${video.thumbBg} border border-zinc-800/80 shrink-0 overflow-hidden flex items-center justify-center cursor-pointer`}
                >
                  <span className="absolute bottom-2 right-2 bg-black/85 font-mono text-[10px] font-bold text-zinc-200 px-1.5 py-0.5 rounded">
                    {video.duration}
                  </span>

                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/30">
                    <div className="w-10 h-10 rounded-full bg-red-600 text-white flex items-center justify-center shadow-lg">
                      <Play className="w-4 h-4 fill-white ml-0.5" />
                    </div>
                  </div>
                </Link>

                {/* Details */}
                <div className="space-y-1.5 overflow-hidden flex-1 py-1">
                  <Link href={`/watch/${video.id}`}>
                    <h3 className="text-sm sm:text-base font-bold text-white group-hover:text-[#fc5b69] transition-colors line-clamp-2 leading-snug cursor-pointer">
                      {video.title}
                    </h3>
                  </Link>

                  <div className="flex items-center gap-1.5 text-xs text-zinc-400">
                    <Link
                      href={`/channel/${video.handle}`}
                      className="font-semibold text-zinc-300 hover:text-white transition-colors"
                    >
                      {video.creator}
                    </Link>
                  </div>

                  <div className="flex items-center gap-2 text-[11px] text-[#797a8e] font-medium pt-0.5">
                    <span>{video.views} views</span>
                    <span>•</span>
                    <span className="text-zinc-400 font-semibold">{video.addedDate}</span>
                    <span>•</span>
                    <span className="text-[10px] bg-white/5 px-2 py-0.5 rounded-md text-zinc-400">
                      {video.category}
                    </span>
                  </div>
                </div>

              </div>

              {/* Right Side: Remove from Saved (Bookmark icon toggle) */}
              <button
                onClick={() => handleRemoveSaved(video.id)}
                title="Remove from Saved"
                className="p-2.5 rounded-xl text-zinc-500 hover:text-red-400 hover:bg-white/5 transition-colors cursor-pointer self-end sm:self-center shrink-0"
              >
                <BookmarkCheck className="w-4 h-4 text-[#fc5b69]" />
              </button>
            </div>
          ))}
        </div>
      )}

    </div>
  );
}