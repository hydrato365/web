"use client";

import React, { useState } from "react";
import Link from "next/link";
import { 
  History as HistoryIcon, 
  Trash2, 
  PauseCircle, 
  PlayCircle, 
  Search, 
  X, 
  Play, 
  Clock, 
  Heart,
  ThumbsUp,
  Sparkles
} from "lucide-react";
import { Button } from "@/components/ui/button";

// Mock History Data (isLiked ပါဝင်သည်)
const initialHistoryGroups = [
  {
    period: "Today",
    videos: [
      {
        id: 1,
        title: "Oppenheimer Full Movie Recap - The Father of the Atomic Bomb",
        creator: "Min Mahar",
        handle: "minmahar",
        views: "125K",
        duration: "38:20",
        progress: 85,
        watchedTime: "Watched 2 hours ago",
        thumbBg: "from-amber-950/60 to-zinc-950",
        isLiked: true, // ❤️ Like ပေးထားသည်
      },
      {
        id: 2,
        title: "Myanmar Digital Banking Reform & Currency Value Analysis 2026",
        creator: "Fintech MM",
        handle: "fintech_mm",
        views: "48K",
        duration: "22:15",
        progress: 40,
        watchedTime: "Watched 4 hours ago",
        thumbBg: "from-blue-950/60 to-zinc-950",
        isLiked: false, // Like မပေးထားပါ
      },
    ],
  },
  {
    period: "Yesterday",
    videos: [
      {
        id: 3,
        title: "Solo Leveling: Ragnarok Episodes 1 to 15 (Motion Comic Recap)",
        creator: "Comic Hub",
        handle: "comic_hub",
        views: "89K",
        duration: "29:40",
        progress: 100,
        watchedTime: "Watched yesterday",
        thumbBg: "from-emerald-950/60 to-zinc-950",
        isLiked: true, // ❤️ Like ပေးထားသည်
      },
      {
        id: 4,
        title: "The Art of War by Sun Tzu (Full Audiobook with Myanmar Explanation)",
        creator: "Book Tube MM",
        handle: "book_tube",
        views: "61K",
        duration: "45:10",
        progress: 15,
        watchedTime: "Watched yesterday",
        thumbBg: "from-purple-950/60 to-zinc-950",
        isLiked: false, // Like မပေးထားပါ
      },
      {
        id: 5,
        title: "Cybersecurity Essentials for Myanmar Remote Workers & Devs",
        creator: "Khit Tech",
        handle: "khit_tech",
        views: "32K",
        duration: "18:25",
        progress: 60,
        watchedTime: "Watched yesterday",
        thumbBg: "from-red-950/60 to-zinc-950",
        isLiked: false, // Like မပေးထားပါ
      },
    ],
  },
];

export default function HistoryPage() {
  const [historyGroups, setHistoryGroups] = useState(initialHistoryGroups);
  const [searchHistory, setSearchHistory] = useState("");
  const [isPaused, setIsPaused] = useState(false);

  // 🌟 Filter State: "all" | "liked" | "unliked"
  const [filterType, setFilterType] = useState<"all" | "liked" | "unliked">("all");

  const handleRemoveVideo = (videoId: number) => {
    setHistoryGroups(
      historyGroups
        .map((group) => ({
          ...group,
          videos: group.videos.filter((v) => v.id !== videoId),
        }))
        .filter((group) => group.videos.length > 0)
    );
  };

  const handleClearAll = () => {
    setHistoryGroups([]);
  };

  const totalVideosCount = historyGroups.reduce((acc, g) => acc + g.videos.length, 0);

  return (
    <div className="px-4 sm:px-8 pb-16 pt-4 max-w-[1400px] mx-auto space-y-7 relative z-10 animate-in fade-in duration-300">
      
      {/* ================= ၁။ HEADER & CONTROLS ================= */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-white/5 pb-6">
        <div>
          <h1 className="text-2xl sm:text-3xl font-black text-white flex items-center gap-3">
            <HistoryIcon className="w-8 h-8 text-[#fc5b69]" />
            Watch History
          </h1>
          <p className="text-xs sm:text-sm text-[#797a8e] mt-1.5">
            Manage your watched videos, filter by liked status, and resume playback.
          </p>
        </div>

        {totalVideosCount > 0 && (
          <div className="flex items-center gap-3 self-start md:self-auto shrink-0">
            <button
              onClick={() => setIsPaused(!isPaused)}
              className={`h-10 px-4 rounded-xl border text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
                isPaused
                  ? "bg-amber-500/10 border-amber-500/30 text-amber-400"
                  : "bg-[#1c1a27] border-white/5 text-zinc-300 hover:text-white hover:bg-zinc-800"
              }`}
            >
              {isPaused ? <PlayCircle className="w-4 h-4" /> : <PauseCircle className="w-4 h-4" />}
              <span>{isPaused ? "Resume History" : "Pause"}</span>
            </button>

            <button
              onClick={handleClearAll}
              className="h-10 px-4 rounded-xl bg-red-600/10 hover:bg-red-600/20 border border-red-600/30 text-red-400 text-xs font-bold flex items-center gap-2 transition-all cursor-pointer"
            >
              <Trash2 className="w-4 h-4" />
              <span>Clear All</span>
            </button>
          </div>
        )}
      </div>

      {/* ================= ၂။ 🎯 FILTER PILLS & SEARCH BAR ================= */}
      {totalVideosCount > 0 && (
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          
          {/* 🌟 Filter Pills (All / Liked Only / Unliked) */}
          <div className="flex items-center gap-2">
            {[
              { id: "all", label: "All Watched", icon: null },
              { id: "liked", label: "Liked Only", icon: Heart },
              { id: "unliked", label: "Unliked", icon: null },
            ].map((tab) => {
              const Icon = tab.icon;
              const isActive = filterType === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setFilterType(tab.id as typeof filterType)}
                  className={`h-10 px-4 rounded-2xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                    isActive
                      ? "bg-[#fc5b69] text-white shadow-[0_4px_14px_rgba(252,91,105,0.3)]"
                      : "bg-[#1c1a27] border border-white/5 text-zinc-400 hover:text-white hover:bg-[#232031]"
                  }`}
                >
                  {Icon && <Icon className={`w-3.5 h-3.5 ${isActive ? "fill-white" : ""}`} />}
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          {/* Search within History */}
          <div className="relative w-full sm:max-w-xs">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
            <input
              type="text"
              placeholder="Filter history..."
              value={searchHistory}
              onChange={(e) => setSearchHistory(e.target.value)}
              className="w-full h-10 bg-[#1c1a27] border border-white/5 rounded-2xl pl-10 pr-4 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-[#fc5b69]/50 transition-colors"
            />
          </div>
        </div>
      )}

      {/* ================= ၃။ HISTORY LIST ================= */}
      {totalVideosCount === 0 ? (
        <div className="py-24 text-center rounded-3xl bg-[#1c1a27]/50 border border-white/5 space-y-3">
          <HistoryIcon className="w-12 h-12 text-zinc-600 mx-auto" />
          <h3 className="text-base font-bold text-white">No watch history yet</h3>
          <p className="text-xs text-[#797a8e] max-w-sm mx-auto leading-relaxed">
            Videos you watch will show up here.
          </p>
        </div>
      ) : (
        <div className="space-y-8">
          {historyGroups.map((group) => {
            // Search နှင့် Liked/Unliked Filter တွဲစစ်ထုတ်ခြင်း
            const filteredGroupVideos = group.videos.filter((v) => {
              const matchesSearch =
                v.title.toLowerCase().includes(searchHistory.toLowerCase()) ||
                v.creator.toLowerCase().includes(searchHistory.toLowerCase());
              
              if (filterType === "liked") return matchesSearch && v.isLiked;
              if (filterType === "unliked") return matchesSearch && !v.isLiked;
              return matchesSearch;
            });

            if (filteredGroupVideos.length === 0) return null;

            return (
              <div key={group.period} className="space-y-4">
                <h2 className="text-xs font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-2">
                  <Clock className="w-3.5 h-3.5 text-[#fc5b69]" />
                  <span>{group.period}</span>
                </h2>

                <div className="space-y-3">
                  {filteredGroupVideos.map((video) => (
                    <div
                      key={video.id}
                      className="group flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between py-2 border-b border-white/5 last:border-b-0 transition-colors"
                    >
                      <div className="flex gap-4 items-start flex-1 overflow-hidden">
                        
                        {/* Thumbnail */}
                        <Link 
                          href={`/watch/${video.id}`}
                          className={`relative w-44 sm:w-56 aspect-[16/9] rounded-xl bg-gradient-to-tr ${video.thumbBg} border border-zinc-800/80 shrink-0 overflow-hidden flex items-center justify-center cursor-pointer`}
                        >
                          <span className="absolute bottom-2 right-2 bg-black/85 font-mono text-[10px] font-bold text-zinc-200 px-1.5 py-0.5 rounded">
                            {video.duration}
                          </span>

                          <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/30">
                            <div className="w-10 h-10 rounded-full bg-red-600 text-white flex items-center justify-center shadow-lg">
                              <Play className="w-4 h-4 fill-white ml-0.5" />
                            </div>
                          </div>

                          {/* Progress Line */}
                          <div className="absolute bottom-0 left-0 right-0 h-1 bg-zinc-800">
                            <div 
                              className="h-full bg-red-600"
                              style={{ width: `${video.progress}%` }}
                            />
                          </div>
                        </Link>

                        {/* Metadata */}
                        <div className="space-y-1.5 overflow-hidden flex-1 py-1">
                          <Link href={`/watch/${video.id}`}>
                            <h3 className="text-sm sm:text-base font-bold text-white group-hover:text-[#fc5b69] transition-colors line-clamp-2 leading-snug cursor-pointer">
                              {video.title}
                            </h3>
                          </Link>

                          <div className="flex items-center gap-2 text-xs text-zinc-400">
                            <Link 
                              href={`/channel/${video.handle}`}
                              className="font-semibold text-zinc-300 hover:text-white transition-colors"
                            >
                              {video.creator}
                            </Link>
                            
                            {/* ❤️ Liked Video ဖြစ်ကြောင်း ပြသည့် Badge */}
                            {video.isLiked && (
                              <span className="inline-flex items-center gap-1 text-[10px] font-bold text-[#fc5b69] bg-[#fc5b69]/10 px-2 py-0.5 rounded-full">
                                <Heart className="w-2.5 h-2.5 fill-[#fc5b69]" /> Liked
                              </span>
                            )}
                          </div>

                          <div className="flex items-center gap-2 text-[11px] text-[#797a8e] font-medium pt-0.5">
                            <span>{video.views} views</span>
                            <span>•</span>
                            <span className="text-zinc-400 font-semibold">{video.watchedTime}</span>
                          </div>
                        </div>

                      </div>

                      {/* Remove Button */}
                      <button
                        onClick={() => handleRemoveVideo(video.id)}
                        title="Remove from history"
                        className="p-2 rounded-xl text-zinc-500 hover:text-red-400 hover:bg-white/5 transition-colors cursor-pointer self-end sm:self-center shrink-0"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      )}

    </div>
  );
}