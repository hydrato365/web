"use client";

import React, { useState } from "react";
import Link from "next/link";
import { 
  Heart, 
  Share2, 
  Eye, 
  LineChart, 
  Bell, 
  Send, 
  MoreHorizontal, 
  CheckCircle2, 
  Volume2, 
  Maximize, 
  Play, 
  Pause,
  Download,
  ChevronDown,
  Users,
  Star,
  Bookmark,
  ThumbsUp
} from "lucide-react";

export default function WatchPage() {
  const [isPlaying, setIsPlaying] = useState(true);
  const [isLiked, setIsLiked] = useState(false);
  const [isDownloadOpen, setIsDownloadOpen] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState<string | null>(null);
  const [inputMessage, setInputMessage] = useState("");
  
  // 🌟 Mobile Tabs State (Up Next vs Comments)
  const [activeTab, setActiveTab] = useState<"upnext" | "comments">("upnext");

  const [chatMessages, setChatMessages] = useState([
    { id: 1, user: "Wijaya Abadi", online: true, check: true, avatar: "from-purple-500 to-indigo-500", text: "Duis aute irure dolor in in proident velit esse cillum dolore eu fugiat" },
    { id: 2, user: "Johny Wise", online: false, check: false, avatar: "from-blue-600 to-blue-800", text: "tempor incididunt ut labore" },
    { id: 3, user: "Budi Hakim", online: true, check: true, avatar: "from-orange-500 to-red-500", text: "Duis aute irure dolor in in proident velit esse cillum dolore eu fugiat" },
    { id: 4, user: "Thomas Hope", online: true, check: false, avatar: "from-yellow-600 to-amber-800", text: "velit esse cillum dolore eu fugiat" },
  ]);

  const handleDownload = (quality: string) => {
    setIsDownloadOpen(false);
    setDownloadProgress(quality);
    setTimeout(() => setDownloadProgress(null), 3000);
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim()) return;
    setChatMessages([...chatMessages, {
      id: Date.now(),
      user: "Thomas (You)",
      online: true,
      check: true,
      avatar: "from-amber-600 to-red-600",
      text: inputMessage
    }]);
    setInputMessage("");
  };

  return (
    <div className="pb-20 sm:pb-12 pt-0 sm:pt-2 w-full grid grid-cols-1 lg:grid-cols-12 gap-0 sm:gap-6 items-start relative z-10 max-w-[1700px] mx-auto sm:px-8">
      
      {/* ============ LEFT COLUMN: VIDEO + METADATA ============ */}
      <div className="lg:col-span-8 flex flex-col w-full">
        
        {/* 🎬 Video Player (Mobile တွင် ဘောင်အပြည့် Edge-to-edge) */}
        <div className="w-full aspect-[16/9] bg-black sm:rounded-xl overflow-hidden relative shadow-2xl group sm:border border-white/5 z-20 sticky top-0 sm:static">
          <div 
            className="absolute inset-0 bg-zinc-900 bg-center bg-cover flex items-center justify-center" 
            style={{ backgroundImage: `url('https://images.unsplash.com/photo-1564982755866-9e8c37d8009d?q=80&w=2000&auto=format&fit=crop')` }}
          >
            <div className="w-32 h-32 bg-amber-500/20 blur-[50px] rounded-full translate-x-12 translate-y-10" />
          </div>
          
          <div className="absolute bottom-5 left-5 right-5 p-4 rounded-2xl bg-black/40 backdrop-blur-md border border-white/10 flex items-center justify-between gap-4">
            <div className="flex items-center gap-4 w-full">
              <div className="px-3 py-1 bg-red-600 rounded-lg text-white font-extrabold text-[10px] uppercase flex items-center gap-1.5 tracking-wider">
                <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" /> LIVE
              </div>

              <button 
                onClick={() => setIsPlaying(!isPlaying)}
                className="text-white hover:scale-110 transition-transform cursor-pointer"
              >
                {isPlaying ? <Pause className="w-4 h-4 fill-white" /> : <Play className="w-4 h-4 fill-white" />}
              </button>

              <div className="flex-1 h-1 bg-white/20 rounded-full cursor-pointer relative overflow-visible flex items-center">
                <div className="h-full w-1/3 bg-[#8c1cff] rounded-l-full relative shadow-[0_0_10px_#8c1cff]" />
                <div className="w-3 h-3 bg-white rounded-full absolute shadow-md cursor-grab" style={{ left: '33%' }} />
              </div>
              
              <span className="text-xs font-mono font-medium text-white px-2">17:34 / 59:32</span>

              <button className="text-white hover:text-red-400 transition-colors"><Volume2 className="w-4 h-4" /></button>
              <button className="text-white hover:text-red-400 transition-colors"><Maximize className="w-4 h-4" /></button>
            </div>
          </div>
        </div>

        {/* 📱 Mobile App Layout Style Metadata */}
        <div className="flex flex-col px-4 sm:px-0 pt-4 pb-2">
          
          {/* Title */}
          <h1 className="text-xl sm:text-2xl font-bold leading-snug text-white">
            The Future of Myanmar's Tech Industry
          </h1>

          {/* Stats */}
          <div className="flex items-center gap-2 text-xs sm:text-sm text-zinc-400 font-medium mt-2">
            <span>384K views</span>
            <span>•</span>
            <span>3 hours ago</span>
            <span>•</span>
            <span className="text-red-500 font-semibold">News & Politics</span>
          </div>

          {/* Description Box */}
          <div className="mt-4 p-3 bg-[#232130] rounded-xl text-xs sm:text-sm text-zinc-300 cursor-pointer border border-white/5 flex flex-col gap-1">
            <p className="line-clamp-2">A deep dive into the evolving tech landscape, exploring opportunities, digital banking reforms, and the impact of recent changes in Myanmar.</p>
            <span className="text-red-400 font-bold">...more</span>
          </div>

          {/* Creator Row + Follow Button */}
          <div className="mt-5 flex items-center justify-between">
            <Link href="/channel/techinsider" className="flex items-center gap-3 group cursor-pointer">
              <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-red-600 flex items-center justify-center font-bold text-white text-sm">
                TE
              </div>
              <div className="flex flex-col">
                <h3 className="text-base font-bold text-white flex items-center gap-1.5 group-hover:text-[#a042ff] transition-colors">
                  Tech Insider MM
                  <CheckCircle2 className="w-3.5 h-3.5 text-red-500 fill-red-500 text-[#131224]" />
                </h3>
                <span className="text-xs text-zinc-400">Vetted Myanmar Creator</span>
              </div>
            </Link>
            
            <button className="h-9 sm:h-10 px-4 sm:px-5 bg-red-600 text-white text-sm font-bold rounded-full transition-transform active:scale-95 shadow-md shadow-red-600/20">
              + Follow
            </button>
          </div>

          {/* Horizontal Scrollable Action Buttons */}
          <div className="mt-5 flex items-center gap-2.5 overflow-x-auto scrollbar-none pb-2">
            <button 
              onClick={() => setIsLiked(!isLiked)}
              className="h-9 px-4 shrink-0 bg-[#232130] rounded-full flex items-center gap-2 text-xs font-bold text-white border border-white/5"
            >
              <ThumbsUp className={`w-4 h-4 ${isLiked ? "fill-white" : ""}`} /> {isLiked ? "38,401" : "38,400"}
            </button>
            <button className="h-9 px-4 shrink-0 bg-[#232130] rounded-full flex items-center gap-2 text-xs font-bold text-white border border-white/5">
              <Bookmark className="w-4 h-4" /> Save
            </button>
            <button className="h-9 px-4 shrink-0 bg-[#232130] rounded-full flex items-center gap-2 text-xs font-bold text-white border border-white/5">
              <Share2 className="w-4 h-4" /> Share
            </button>
            <Link href="/stars" className="h-9 px-4 shrink-0 bg-amber-400 text-zinc-950 rounded-full flex items-center gap-2 text-xs font-black shadow-md shadow-amber-500/20">
              <Star className="w-4 h-4 fill-zinc-950" /> Send Star
            </Link>
          </div>

        </div>
        </div>

      {/* ============ RIGHT COLUMN: CHAT + RELATED ============ */}
      <div className="lg:col-span-4 flex flex-col gap-8 w-full max-w-[420px] mx-auto xl:mx-0">
        
        {/* Live Chat Pane */}
        <div className="w-full bg-[#1c1a27] rounded-3xl border border-white/5 flex flex-col p-6 shadow-xl relative">
          <div className="flex items-center justify-between mb-6 pb-2">
            <h3 className="font-bold text-base text-white">Live Chat</h3>
            <span className="flex items-center gap-2 text-[11px] font-bold text-[#797a8e]">
              <Users className="w-4 h-4" /> 15,986 people
            </span>
          </div>

          <div className="space-y-6 max-h-[300px] overflow-y-auto pr-2 scrollbar-none flex-1 mb-4">
            {chatMessages.map((user) => (
              <div key={user.id} className="flex gap-4">
                <div className="relative shrink-0">
                  <div className={`w-9 h-9 rounded-full bg-gradient-to-tr ${user.avatar} font-bold text-xs flex items-center justify-center text-white border border-[#1e1c2a]`}>
                    {user.user.charAt(0)}
                  </div>
                  {user.check && (
                    <div className="absolute -bottom-1 -right-1 bg-blue-500 w-3.5 h-3.5 rounded-full flex items-center justify-center border-2 border-[#1c1a27]">
                      <CheckCircle2 className="w-2.5 h-2.5 text-white" />
                    </div>
                  )}
                </div>
                <div className="space-y-1">
                      <div className="flex items-center gap-2 text-sm font-bold text-white">
                        {user.user} 
                        {user.online ? <div className="w-2 h-2 bg-[#1bc285] rounded-full" /> : <div className="w-2 h-2 bg-[#fc5b69] rounded-full" />}
                      </div>
                      <p className="text-sm leading-relaxed text-zinc-100">{user.text}</p>
                    </div>
              </div>
            ))}
          </div>

          <form onSubmit={handleSendMessage} className="relative flex items-center h-12 w-full mt-2">
            <input 
              type="text" 
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              placeholder="Write your message..." 
              className="w-full h-full rounded-2xl bg-[#14121d] border border-transparent pl-12 pr-12 text-sm font-medium text-white placeholder-zinc-400 focus:outline-none focus:border-[#8c1cff]/50"
            />
            <MoreHorizontal className="absolute left-4 w-4 h-4 text-zinc-500" />
            <button type="submit" className="absolute right-1 w-10 h-10 rounded-xl bg-[#8c1cff] flex items-center justify-center shadow-lg transition-transform hover:scale-105 hover:bg-[#7818e3] cursor-pointer">
              <Send className="w-3.5 h-3.5 text-white mr-0.5" />
            </button>
          </form>
        </div>

        {/* Related Videos */}
        <div className="space-y-4 w-full">
          <h3 className="font-bold text-base text-white pl-2">Related Videos</h3>
          <div className="space-y-4">
            {[
              { id: 2, title: "Prepare for your first skateboard jump", author: "Min Mahar", handle: "minmahar", views: "125,908 views", time: "2 days ago", bg: "from-zinc-500 to-slate-700" },
              { id: 3, title: "Tips to playing skateboard on the ramp", author: "Fintech MM", handle: "fintech_mm", views: "125,908 views", time: "2 days ago", bg: "from-amber-600 to-amber-900" }
            ].map((v, i) => (
              <div key={i} className="flex gap-4 p-1 hover:bg-white/5 transition-colors rounded-xl cursor-pointer group">
                {/* 🔗 Thumbnail နှိပ်လျှင် Watch Page သို့သွားမည် */}
                <Link href={`/watch/${v.id}`} className={`w-32 h-[76px] rounded-[18px] bg-gradient-to-tr ${v.bg} border border-white/5 flex items-center justify-center shrink-0`} />
                
                <div className="flex flex-col py-0.5 pr-2 flex-1">
                    <Link href={`/watch/${v.id}`}>
                      <h4 className="text-base font-bold text-white group-hover:text-[#a042ff] transition-colors leading-snug line-clamp-2">
                        {v.title}
                      </h4>
                    </Link>

                    <Link href={`/channel/${v.handle}`} className="text-sm font-semibold text-zinc-200 hover:text-white mt-1.5 transition-colors w-max">
                      {v.author}
                    </Link>
                    <p className="text-xs sm:text-sm text-zinc-400 mt-1 font-medium">{v.views} • {v.time}</p>
                  </div>
              </div>
            ))}
          </div>
          <button className="w-full h-11 bg-[#8c1cff] hover:bg-[#7a14e6] text-white rounded-[16px] text-xs font-bold transition-all shadow-[0_5px_15px_rgba(140,28,255,0.3)] mt-2 cursor-pointer">
            See All related videos (32)
          </button>
        </div>

      </div>
    </div>
  );
}