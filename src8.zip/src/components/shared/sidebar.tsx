"use client";

import React, { useEffect, useState, useRef } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { 
  Home, 
  Users, 
  Bookmark, 
  MessageSquare, 
  History, 
  ChevronDown,
  Download
} from "lucide-react";
import { layoutConfig } from "@/lib/layout-config";
import { BrandLogo } from "@/components/shared/brand-logo";

const mainNavItems = [
  { href: "/", label: "Home", icon: Home },
  { href: "/messages", label: "Messages", icon: MessageSquare },
  { href: "/saved", label: "Saved", icon: Bookmark },
  { href: "/downloads", label: "Downloads", icon: Download },
  { href: "/history", label: "History", icon: History },
];

const followedChannels = [
  { id: 1, name: "Min Mahar", handle: "minmahar", avatar: "from-amber-600 to-amber-900", isLive: true },
  { id: 2, name: "Fintech MM", handle: "fintech_mm", avatar: "from-blue-600 to-blue-800", isLive: true },
  { id: 3, name: "Comic Hub", handle: "comic_hub", avatar: "from-emerald-600 to-teal-800", isLive: false },
  { id: 4, name: "Book Tube MM", handle: "book_tube", avatar: "from-purple-600 to-indigo-800", isLive: false },
  { id: 5, name: "Khit Tech", handle: "khit_tech", avatar: "from-red-600 to-rose-900", isLive: false },
  { id: 6, name: "Gamer MM", handle: "gamer_mm", avatar: "from-orange-600 to-amber-800", isLive: false },
];

export function Sidebar() {
  const pathname = usePathname();
  const [isSubOpen, setIsSubOpen] = useState(true);
  const [isLoadingChannels, setIsLoadingChannels] = useState(true);

  useEffect(() => {
    // ၂.၅ စက္ကန့်အကြာမှ Data တက်လာသယောင် Fake လုပ်မည်
    const timer = setTimeout(() => setIsLoadingChannels(false), 2500);
    return () => clearTimeout(timer);
  }, []);

  return (
      <aside className="hidden md:flex w-20 bg-[#131224] border-r border-white/5 flex-col items-center py-6 h-screen shrink-0 z-50 sticky top-0 select-none">
      
      {/* ၁။ Logo */}
      <Link 
        href="/" 
        title="Khit Home"
        className="mb-4 hover:scale-105 transition-transform shrink-0"
      >
        <BrandLogo />
      </Link>

      {/* ၂။ အပေါ်ပိုင်း Main Navigation ခလုတ်များ (Home, Messages, Saved, Downloads, History) */}
      <div className="flex flex-col items-center gap-1 w-full shrink-0">
        {mainNavItems.map((item) => {
          const Icon = item.icon;
          const isActive = pathname === item.href;
          return (
            <Link 
              key={item.href}
              href={item.href} 
              title={item.label}
              className="relative group w-full flex justify-center shrink-0 px-1"
            >
              {isActive && (
                <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1.5 h-6 rounded-r-full bg-[#8c1cff] shadow-[0_0_12px_#8c1cff]" />
              )}
              
              <div className={`w-[72px] py-2 rounded-2xl transition-all duration-200 flex flex-col items-center justify-center gap-1 hover:scale-105 active:scale-95 ${
                isActive ? "text-white" : "text-zinc-400 hover:text-white"
              }`}>
                <Icon className={`w-5 h-5 transition-all duration-200 ${isActive ? "text-[#a042ff]" : "text-zinc-400 group-hover:text-white group-hover:scale-110"}`} />
                <span className="text-[11px] font-bold text-center tracking-tight leading-tight px-0.5">
                  {item.label}
                </span>
              </div>
            </Link>
          );
        })}
      </div>

      {/* ၃။ အလယ်ပိုင်း Tuned ခလုတ်နှင့် Scroll လုပ်နိုင်သော Creator Avatars စာရင်း */}
      <div className="pt-2 border-t border-white/5 flex flex-col w-full items-center shrink-0 mt-2">
        <div className="relative group w-full flex flex-col items-center shrink-0 px-1">
          {pathname === "/subscriptions" && (
            <div className="absolute left-0 top-3 w-1.5 h-6 rounded-r-full bg-[#8c1cff] shadow-[0_0_12px_#8c1cff]" />
          )}
          <Link
            href="/subscriptions"
            title="Subscriptions Feed"
            className={`w-[72px] pt-1.5 pb-0.5 rounded-t-2xl transition-all duration-200 flex flex-col items-center justify-center gap-0.5 hover:scale-105 active:scale-95 ${
              pathname === "/subscriptions" ? "text-white" : "text-zinc-400 hover:text-white"
            }`}
          >
            <Users className={`w-5 h-5 transition-all duration-200 ${pathname === "/subscriptions" ? "text-[#a042ff]" : "text-zinc-400 group-hover:text-white group-hover:scale-110"}`} />
            <span className="text-[11px] font-bold text-center tracking-tight leading-tight px-0.5">
              Tuned
            </span>
          </Link>
          <button
            onClick={() => setIsSubOpen(!isSubOpen)}
            title={isSubOpen ? "Collapse Channels" : "Expand Channels"}
            className="w-[72px] py-0.5 flex items-center justify-center text-zinc-500 hover:text-white transition-colors cursor-pointer"
          >
            <ChevronDown className={`w-3 h-3 transition-transform duration-200 ${isSubOpen ? "rotate-180 text-[#a042ff]" : ""}`} />
          </button>
        </div>
      </div>

      {isSubOpen && (
        <div className="flex-1 w-full flex flex-col items-center gap-3 py-2 overflow-y-auto scrollbar-none min-h-0">
          {isLoadingChannels ? (
            [...Array(4)].map((_, i) => (
              <div key={i} className="w-8 h-8 rounded-full bg-[#1c1a30] animate-pulse border border-white/5 shrink-0" />
            ))
          ) : (
            followedChannels.map((channel, index) => (
              <Link
                key={channel.id}
                href={`/channel/${channel.handle}`}
                title={`${channel.name}${channel.isLive ? " (LIVE NOW)" : ""}`}
                className="relative group shrink-0 hover:scale-110 transition-transform animate-in fade-in zoom-in-95 duration-500"
                style={{ animationDelay: `${index * 75}ms`, animationFillMode: "both" }}
              >
                <div className={`w-8 h-8 rounded-full bg-gradient-to-tr ${channel.avatar} flex items-center justify-center font-bold text-xs text-white border transition-all ${
                  channel.isLive 
                    ? "border-red-500 shadow-[0_0_10px_rgba(239,68,68,0.5)]" 
                    : "border-white/10 group-hover:border-white/30"
                }`}>
                  {channel.name.charAt(0)}
                </div>
                {channel.isLive && (
                  <span className="absolute -bottom-0.5 -right-0.5 w-2 h-2 bg-red-500 rounded-full border-2 border-[#131224] animate-pulse" />
                )}
              </Link>
            ))
          )}
        </div>
      )}

    </aside>
  );
}