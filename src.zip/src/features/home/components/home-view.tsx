"use client";
import React, { useState } from "react";
import Link from "next/link";
import { Play, Star, Eye, CheckCircle2, Sparkles } from "lucide-react";
import { mockVideos, categories } from "@/lib/data";
import { useTranslations } from "next-intl";

interface BackendVideo {
  id: string;
  creator_id: string;
  title: string;
  description: string;
  video_url: string;
  thumbnail_url: string;
  views: number;
  is_premium: boolean;
  created_at: string;
}

export function HomeView() {
  const t = useTranslations("Home");
  const [activeCategory, setActiveCategory] = useState("All");
  const [videos, setVideos] = useState<BackendVideo[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  React.useEffect(() => {
    const host = typeof window !== "undefined" ? window.location.hostname : "localhost";
    fetch(`http://${host}:8080/videos`)
      .then((res) => res.json())
      .then((data) => {
        if (Array.isArray(data)) {
          setVideos(data);
        }
        setIsLoading(false);
      })
      .catch((err) => {
        console.error("Failed to load videos from backend:", err);
        setIsLoading(false);
      });
  }, []);

  const filteredVideos = videos;

  return (
    <div className="px-4 sm:px-8 pb-4 pt-4 space-y-4 max-w-[1700px] mx-auto">
      {/* 🌟 Categories လေးများ ဖုန်းစခရင်အစွန်းထိ ဆွဲနိုင်စေရန် -mx-4 px-4 ဖြင့် ဆန့်ထုတ်ထားသည် */}
      <div className="flex items-center gap-2.5 overflow-x-auto pb-1 scrollbar-none -mx-4 px-4 sm:-mx-8 sm:px-8">
        {categories.map((cat) => (
          <button key={cat} onClick={() => setActiveCategory(cat)} className={`px-4.5 py-2.5 rounded-2xl text-sm font-bold whitespace-nowrap transition-colors border cursor-pointer ${activeCategory === cat ? "bg-[#8c1cff] text-white border-[#8c1cff]" : "bg-[#1c1a27] border-white/5 text-zinc-400 hover:text-white hover:bg-[#232031]"}`}>
            {t(`categories.${cat}` as any)}
          </button>
        ))}
      </div>

      <div className="flex items-center justify-between pt-2">
        <h2 className="text-xl font-black text-white flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-[#a042ff]" />
          <span>{activeCategory === "All" ? t("featured") : (t.has(`categories.${activeCategory}` as any) ? t(`categories.${activeCategory}` as any) : activeCategory)}</span>
        </h2>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 animate-pulse">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="flex flex-col gap-2.5">
              {/* Thumbnail နေရာလွတ် */}
              <div className="w-full aspect-[16/9] rounded-xl bg-[#1c1a27] border border-white/5" />
              
              {/* Avatar နှင့် စာသား နေရာလွတ် (တကယ့် Card ပါ px-0.5 နှင့် space-y-1.5 ကို အတိအကျ ယူထားသည်) */}
              <div className="flex items-start gap-3 px-0.5">
                <div className="w-10 h-10 rounded-full bg-[#1c1a27] shrink-0" />
                <div className="flex-1 space-y-1.5 pt-0.5">
                  <div className="h-5 bg-[#1c1a27] rounded-md w-[85%]" />
                  <div className="h-4 bg-[#1c1a27]/60 rounded-md w-[50%] mt-2" />
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : filteredVideos.length === 0 ? (
        <div className="py-20 text-center text-zinc-500 text-sm">
          {t("noVideos")}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredVideos.map((video) => (
            <div key={video.id} className="group cursor-pointer flex flex-col gap-2.5">
              
              {/* 🔗 Video Link (Thumbnail နှိပ်လျှင် Watch Page သို့သွားမည်) */}
              <Link href={`/watch/${video.id}`} className="relative w-full aspect-[16/9] rounded-xl bg-zinc-900 border border-white/5 overflow-hidden flex items-center justify-center">
                <img 
                  src={video.thumbnail_url || "https://images.unsplash.com/photo-1611162617474-5b21e879e113"} 
                  alt={video.title} 
                  className="w-full h-full object-cover group-hover:scale-105 opacity-0 transition-all duration-700 ease-in-out" 
                  onLoad={(e) => e.currentTarget.classList.remove("opacity-0")}
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent pointer-events-none" />
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/20">
                  <div className="w-12 h-12 rounded-full bg-[#8c1cff] text-white flex items-center justify-center shadow-lg transform group-hover:scale-110 transition-transform"><Play className="w-5 h-5 fill-white ml-0.5" /></div>
                </div>
              </Link>

              {/* Creator Avatar & Video Details */}
              <div className="flex items-start gap-3 px-0.5">
                <Link href={`/channel/khit_admin`} className="relative shrink-0 z-10 rounded-full hover:scale-105 transition-transform">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-purple-600 to-indigo-800 flex items-center justify-center font-bold text-sm text-white">
                    K
                  </div>
                </Link>

                <div className="flex-1 space-y-1.5 overflow-hidden">
                  <Link href={`/watch/${video.id}`}>
                    <h3 className="text-base font-bold text-white group-hover:text-[#a042ff] transition-colors line-clamp-2 leading-relaxed">
                      {video.title}
                    </h3>
                  </Link>
                  
                  <div className="flex flex-col gap-1 text-xs text-[#797a8e] font-medium pt-0.5">
                    <Link href={`/channel/khit_admin`} className="flex items-center gap-1.5 text-sm text-zinc-300 hover:text-white transition-colors z-10">
                      <span className="font-semibold">Khit Creator</span>
                      <CheckCircle2 className="w-3.5 h-3.5 text-blue-500 fill-blue-500 text-[#1c1a27]" />
                    </Link>
                    <div className="flex items-center gap-1.5">
                      <Eye className="w-3.5 h-3.5 text-zinc-500" />
                      <span>{video.views} {t("views")}</span>
                      <span>•</span>
                      <span>{new Date(video.created_at).toLocaleDateString()}</span>
                    </div>
                  </div>
                </div>
              </div>

            </div>
          ))}
        </div>
      )}
    </div>
  );
}