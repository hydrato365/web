"use client";

import React from "react";

export function PullToRefresh({ children }: { children: React.ReactNode }) {
  return (
    <main
      id="main-scroll-area"
      className="flex-1 pt-16 md:pt-0 pb-16 md:pb-0 relative w-full"
    >
      <div className="min-h-full">
        {children}
      </div>
    </main>
  );
}