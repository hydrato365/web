import type { Metadata } from "next";
import { Inter, Noto_Sans_Myanmar } from "next/font/google";
import "./globals.css";
import { Sidebar } from "@/components/shared/sidebar";
import { Header } from "@/components/shared/header";
import { Suspense } from "react"; // <--- 🌟 ဤအရာကို ထည့်သွင်းရပါမည်
import NextTopLoader from "nextjs-toploader"; // 🌟 Page Navigation Bar

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" });
const notoSansMyanmar = Noto_Sans_Myanmar({ weight: ["400", "500", "700"], subsets: ["myanmar"], variable: "--font-myanmar" });

import type { Viewport } from "next";

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
  interactiveWidget: "resizes-content",
};

export const metadata: Metadata = {
  title: "KHIT.TO",
  description: "Premium Streaming Platform",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className={`${inter.variable} ${notoSansMyanmar.variable} antialiased bg-[#131224] text-white overflow-hidden`}>
        
        {/* 🌟 NextTopLoader (Page Navigation Progress Bar) */}
        <NextTopLoader
          color="#8c1cff"
          initialPosition={0.08}
          crawlSpeed={200}
          height={3}
          crawl={true}
          showSpinner={false}
          easing="ease"
          speed={200}
          shadow="0 0 15px #8c1cff,0 0 5px #8c1cff"
          zIndex={99999}
        />

        <div className="flex h-screen w-full">
          {/* 
            🌟 Next.js 15 ၏ usePathname Error ကို ဖြေရှင်းရန် 
            Sidebar အား Suspense ဖြင့် အုပ်ပေးထားသည် 
          */}
          <Suspense fallback={<aside className="hidden md:flex w-20 bg-[#131224] border-r border-white/5 h-screen shrink-0 z-50" />}>
            <Sidebar />
          </Suspense>

          <div className="flex-1 flex flex-col h-screen overflow-hidden relative">
            {/* Header အားလည်း နောင်တစ်ချိန် Error ကင်းစေရန် Suspense ဖြင့် အုပ်ထားပါသည် */}
            <Suspense fallback={<header className="h-16 bg-[#131224]/80 border-b border-white/5" />}>
              <Header />
            </Suspense>

            {/* Dynamic Pages (Home, Watch စသည်တို့ ဤနေရာတွင် ပေါ်မည်) */}
            <main id="main-scroll-area" className="flex-1 overflow-y-auto overscroll-y-auto pb-16 md:pb-0" style={{ WebkitOverflowScrolling: "touch" }}>
              {children}
            </main>
          </div>
        </div>

      </body>
    </html>
  );
}