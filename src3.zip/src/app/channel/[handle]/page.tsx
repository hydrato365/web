"use client";

import React, { useState } from "react";
import Link from "next/link";
import { 
  CheckCircle2, 
  Bell, 
  Share2, 
  Star, 
  Play, 
  Eye, 
  LayoutGrid, 
  ListVideo, 
  Info 
} from "lucide-react";
import { mockVideos } from "@/lib/data";

export default function CreatorChannelPage() {
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [activeTab, setActiveTab] = useState<"videos" | "playlists" | "about">("videos");

  // ဒီ Creator ရဲ့ ဗီဒီယိုတွေချည်း စစ်ထုတ်လိုက်သည်ဟု သဘောထားပါ
  const creatorVideos = mockVideos.slice(0, 4); 

  return (
    <div className="min-h-screen relative z-10 animate-in fade-in duration-300">
      
      {/* ================= ၁။ CHANNEL BANNER ================= */}
      <div className="w-full h-48 sm:h-64 md:h-72 bg-zinc-900 relative overflow-hidden">
        {/* Mock Banner Image with Gradient Overlay */}
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url('https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=2564&auto=format&fit=crop')` }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#14121d] via-[#14121d]/40 to-transparent" />
        
        {/* Floating Ambient Glow */}
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-red-600/30 blur-[100px] rounded-full" />
      </div>

      {/* ================= ၂။ CREATOR HEADER INFO ================= */}
      <div className="max-w-[1500px] mx-auto px-6 sm:px-10 -mt-16 sm:-mt-20 relative z-20">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          
          {/* Avatar & Info */}
          <div className="flex flex-col sm:flex-row sm:items-end gap-5">
            {/* Big Avatar (w-fit ထည့်ထားသဖြင့် Checkmark Badge သည် ညာဘက်အစွန်းသို့ မပြေးတော့ဘဲ Avatar ပေါ်တွင်သာ ကပ်နေမည်) */}
            <div className="relative shrink-0 w-fit">
              <div className="w-28 h-28 sm:w-36 sm:h-36 rounded-full bg-gradient-to-tr from-amber-600 to-red-600 border-4 border-[#14121d] shadow-2xl flex items-center justify-center font-bold text-4xl text-white">
                M
              </div>
              <div className="absolute bottom-1 right-1 sm:bottom-2 sm:right-2 bg-blue-500 rounded-full w-7 h-7 border-[3px] border-[#14121d] flex items-center justify-center shadow-lg">
                <CheckCircle2 className="w-4 h-4 text-white" />
              </div>
            </div>

            {/* Texts */}
            <div className="space-y-2 mb-2">
              <h1 className="text-2xl sm:text-4xl font-black text-white tracking-tight">
                Min Mahar
              </h1>
              <div className="flex items-center gap-3 text-sm text-[#797a8e] font-medium">
                <span className="text-zinc-300">@minmahar_recap</span>
                <span>•</span>
                <span>128K Subscribers</span>
                <span>•</span>
                <span>42 Videos</span>
              </div>
              <p className="text-xs sm:text-sm text-zinc-400 max-w-2xl line-clamp-2 leading-relaxed pt-1">
                မြန်မာလို ရှင်းလင်းပြတ်သားတဲ့ ရုပ်ရှင်ဇာတ်လမ်း သုံးသပ်ချက်များ၊ စိတ်ဝင်စားဖွယ် သမိုင်းကြောင်းများနှင့် Knowledge Sharing Content များကို အပတ်စဉ် ပုံမှန် တင်ဆက်ပေးနေသော ချန်နယ် ဖြစ်ပါတယ်။
              </p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center gap-3 md:mb-4 shrink-0">
            {/* Stars Support Button */}
            <button className="h-11 px-5 rounded-2xl bg-amber-500/10 border border-amber-500/20 hover:bg-amber-500/20 text-amber-400 text-sm font-bold flex items-center gap-2 transition-all shadow-sm">
              <Star className="w-4 h-4 fill-amber-400" /> Support
            </button>

            {/* Share */}
            <button className="h-11 w-11 rounded-2xl bg-[#1c1a27] hover:bg-[#232031] border border-white/5 text-zinc-300 flex items-center justify-center transition-all shadow-sm">
              <Share2 className="w-4 h-4" />
            </button>

            {/* Subscribe Button (Subscribe မလုပ်ရသေးချိန်တွင် rounded-2xl ဖြင့် ညာဘက်ထောင့်ပါ ဝိုင်းစေခြင်း) */}
            <div className="flex items-center">
              <button 
                onClick={() => setIsSubscribed(!isSubscribed)}
                className={`h-11 px-6 font-black text-sm transition-all flex items-center gap-2 ${
                  isSubscribed 
                    ? "rounded-l-2xl bg-[#1c1a27] text-white border border-white/10 border-r-0" 
                    : "rounded-2xl bg-[#8c1cff] hover:bg-[#9d3eff] text-white shadow-[0_5px_20px_rgba(140,28,255,0.35)]"
                }`}
              >
                {isSubscribed ? "Subscribed" : "Subscribe"}
              </button>
              {isSubscribed && (
                <button className="h-11 px-3 rounded-r-2xl bg-[#1c1a27] border border-white/10 border-l-0 text-zinc-300 hover:text-white transition-colors">
                  <Bell className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* ================= ၃။ TABS (Videos, Playlists, About) ================= */}
      <div className="max-w-[1500px] mx-auto px-6 sm:px-10 mt-10">
        <div className="flex items-center gap-6 border-b border-white/5">
          {[
            { id: "videos", label: "Videos", icon: LayoutGrid },
            { id: "playlists", label: "Playlists", icon: ListVideo },
            { id: "about", label: "About", icon: Info },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 pb-4 text-sm font-bold border-b-2 transition-all cursor-pointer ${
                activeTab === tab.id
                  ? "border-[#8c1cff] text-white"
                  : "border-transparent text-zinc-400 hover:text-zinc-200"
              }`}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </div>

        {/* ================= ၄။ TAB CONTENT ================= */}
        <div className="py-8">
          
          {/* VIDEOS TAB */}
          {activeTab === "videos" && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold text-white">Latest Uploads</h3>
                <button className="text-xs font-semibold text-zinc-400 hover:text-white transition-colors bg-[#1c1a27] px-3 py-1.5 rounded-lg border border-white/5">
                  Sort by: Newest
                </button>
              </div>

              {/* Video Grid (Flat & Clean Borderless Style) */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {creatorVideos.map((video) => (
                  <Link
                    key={video.id}
                    href={`/watch/${video.id}`}
                    className="group cursor-pointer flex flex-col gap-2.5"
                  >
                    <div className={`relative w-full aspect-[16/9] rounded-xl bg-gradient-to-tr ${video.thumbnailBg} border border-zinc-800/80 overflow-hidden flex items-center justify-center`}>
                      <span className="absolute bottom-3 right-3 bg-black/85 font-mono text-xs font-bold text-zinc-200 px-2 py-0.5 rounded-md backdrop-blur-sm">
                        {video.duration}
                      </span>
                      <div className="absolute top-3 right-3 px-2.5 py-1 rounded-full bg-amber-500/20 backdrop-blur-md border border-amber-500/30 text-amber-300 text-xs font-black flex items-center gap-1 shadow-sm">
                        <Star className="w-3 h-3 fill-amber-400" />
                        <span>+{video.stars.toLocaleString()}</span>
                      </div>
                      <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                        <div className="w-12 h-12 rounded-full bg-[#8c1cff] text-white flex items-center justify-center shadow-lg shadow-[#8c1cff]/40 transform group-hover:scale-110 transition-transform">
                          <Play className="w-5 h-5 fill-white ml-0.5" />
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-col space-y-1.5 px-0.5">
                      <h3 className="text-base font-bold text-white group-hover:text-[#a042ff] transition-colors line-clamp-2 leading-relaxed">
                        {video.title}
                      </h3>
                      <div className="flex items-center gap-2 text-xs text-[#797a8e] font-medium pt-0.5">
                        <span className="flex items-center gap-1">
                          <Eye className="w-3.5 h-3.5 text-zinc-500" />
                          {video.views} views
                        </span>
                        <span>•</span>
                        <span>{video.time}</span>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          )}

          {/* PLAYLISTS TAB (Placeholder) */}
          {activeTab === "playlists" && (
            <div className="py-20 text-center border border-dashed border-white/10 rounded-3xl bg-[#1c1a27]/50">
              <ListVideo className="w-10 h-10 text-zinc-600 mx-auto mb-3" />
              <h3 className="text-base font-bold text-zinc-400">No playlists yet</h3>
            </div>
          )}

          {/* ABOUT TAB (Placeholder) */}
          {activeTab === "about" && (
            <div className="max-w-3xl bg-[#1c1a27] border border-white/5 rounded-3xl p-8 space-y-6 shadow-xl">
              <div>
                <h3 className="text-sm font-bold text-white mb-2">Description</h3>
                <p className="text-sm text-zinc-400 leading-relaxed">
                  မြန်မာလို ရှင်းလင်းပြတ်သားတဲ့ ရုပ်ရှင်ဇာတ်လမ်း သုံးသပ်ချက်များ၊ စိတ်ဝင်စားဖွယ် သမိုင်းကြောင်းများနှင့် Knowledge Sharing Content များကို အပတ်စဉ် ပုံမှန် တင်ဆက်ပေးနေသော ချန်နယ် ဖြစ်ပါတယ်။ Business Inquiries များအတွက် အောက်ပါ Email သို့ ဆက်သွယ်နိုင်ပါသည်။
                </p>
              </div>
              <div className="pt-4 border-t border-white/5">
                <h3 className="text-sm font-bold text-white mb-3">Links</h3>
                <div className="space-y-2">
                  <a href="#" className="text-sm font-semibold text-blue-400 hover:underline">Facebook Page</a><br/>
                  <a href="#" className="text-sm font-semibold text-blue-400 hover:underline">Telegram Channel</a>
                </div>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}