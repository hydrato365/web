"use client";

import React, { useState } from "react";
import Link from "next/link";
import { 
  MessageSquare, 
  CheckCircle2, 
  Search, 
  X,
  Crown
} from "lucide-react";

interface Conversation {
  id: number;
  creator: string;
  handle: string;
  avatar: string;
  verified: boolean;
  isVIPChannel?: boolean;
  lastMessage: string;
  time: string;
  unreadCount: number;
}

const mockConversations: Conversation[] = [
  {
    id: 1,
    creator: "Min Mahar",
    handle: "minmahar",
    avatar: "from-amber-600 to-amber-900",
    verified: true,
    lastMessage: "မင်္ဂလာပါဗျာ! အခုတင်ပေးလိုက်တဲ့ recap နဲ့ ပတ်သက်ပြီး မေးခွန်းတွေ မေးလို့ရပါတယ်ခင်ဗျာ။",
    time: "2m ago",
    unreadCount: 2,
  },
  {
    id: 2,
    creator: "Fintech MM",
    handle: "fintech_mm",
    avatar: "from-blue-600 to-blue-800",
    verified: true,
    isVIPChannel: true,
    lastMessage: "📢 VIP အဖွဲ့ဝင်များအတွက် Digital Banking Analysis အသစ် တင်ပေးထားပါပြီ။",
    time: "1h ago",
    unreadCount: 1,
  },
  {
    id: 3,
    creator: "Comic Hub",
    handle: "comic_hub",
    avatar: "from-emerald-600 to-teal-800",
    verified: false,
    lastMessage: "ကျေးဇူးတင်ပါတယ်ခင်ဗျာ! Solo Leveling အပိုင်းသစ် မနက်ဖြန် လာပါမယ်။",
    time: "Yesterday",
    unreadCount: 0,
  },
];

export default function MessagesPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeFilter, setActiveFilter] = useState<"all" | "vip" | "unread">("all");

  const filteredConversations = mockConversations.filter((c) => {
    const matchesSearch =
      c.creator.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.handle.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.lastMessage.toLowerCase().includes(searchQuery.toLowerCase());

    if (activeFilter === "vip") return matchesSearch && c.isVIPChannel;
    if (activeFilter === "unread") return matchesSearch && c.unreadCount > 0;
    return matchesSearch;
  });

  const totalUnread = mockConversations.reduce((acc, c) => acc + c.unreadCount, 0);

  return (
    <div className="px-4 sm:px-6 pb-24 md:pb-16 pt-2 max-w-[860px] mx-auto space-y-4 relative z-10 animate-in fade-in duration-200">
      
      {/* 📌 Sticky Header: Messages Title နှင့် Search Box (၂ ခုတည်းသာ ကပ်နေမည်) */}
      <div className="sticky top-0 z-20 bg-[#131224]/95 backdrop-blur-md pt-2 pb-3 space-y-3 border-b border-white/5 -mx-4 px-4 sm:-mx-6 sm:px-6">
        
        {/* ၁။ Messages Title */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              Messages
            </h1>
            {totalUnread > 0 && (
              <span className="px-2.5 py-0.5 rounded-full bg-[#8c1cff] text-white text-xs font-black shadow-[0_0_12px_rgba(140,28,255,0.4)]">
                {totalUnread} new
              </span>
            )}
          </div>
        </div>

        {/* ၂။ Search Box */}
        <div className="relative flex items-center">
          <Search className="absolute left-4 w-4 h-4 text-zinc-500 shrink-0 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search creators or messages..."
            className="w-full h-11 bg-[#1c1a2c] border border-white/5 rounded-2xl pl-11 pr-10 text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-[#8c1cff] transition-all shadow-sm"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery("")}
              className="absolute right-3.5 p-1 rounded-full text-zinc-400 hover:text-white cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

      </div>

      {/* 🏷️ Filter Pills (Sticky အပြင်ဘက်သို့ ထုတ်ထားသဖြင့် Scroll ဆွဲပါက အပေါ်သို့ သဘာဝအတိုင်း ပါသွားမည်) */}
      <div className="flex items-center gap-2 overflow-x-auto scrollbar-none pt-1 pb-0.5">
        {[
          { id: "all", label: "All Chats" },
          { id: "vip", label: "VIP Broadcasts", icon: Crown },
          { id: "unread", label: "Unread" },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeFilter === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveFilter(tab.id as typeof activeFilter)}
              className={`h-8 px-4 rounded-full text-xs font-bold transition-all flex items-center gap-1.5 shrink-0 cursor-pointer ${
                isActive
                  ? "bg-[#8c1cff] text-white shadow-[0_2px_10px_rgba(140,28,255,0.35)]"
                  : "bg-[#1c1a27] text-zinc-400 hover:text-white border border-white/5"
              }`}
            >
              {Icon && <Icon className="w-3 h-3 text-amber-400" />}
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* 💬 Modern Flat Conversations Feed (Telegram / iOS စတိုင် Box ဘောင်များ မပါဘဲ သန့်ရှင်းသော UI) */}
      <div className="divide-y divide-white/5 pt-1">
        {filteredConversations.length === 0 ? (
          <div className="py-20 text-center text-xs text-zinc-500 space-y-1">
            <p className="font-bold text-zinc-400">No conversations found</p>
            <p>Try searching for a different creator or message</p>
          </div>
        ) : (
          filteredConversations.map((chat) => (
            <Link
              key={chat.id}
              href={`/messages/${chat.id}`}
              className="py-3.5 px-2 flex items-center gap-3.5 rounded-2xl hover:bg-white/5 active:bg-white/10 transition-colors cursor-pointer group"
            >
              {/* Creator Avatar with Status Indicator */}
              <div className="relative shrink-0">
                <div className={`w-12 h-12 rounded-full bg-gradient-to-tr ${chat.avatar} font-bold text-sm flex items-center justify-center text-white shadow-md group-hover:scale-105 transition-transform`}>
                  {chat.creator.charAt(0)}
                </div>
                {chat.isVIPChannel ? (
                  <span className="absolute -bottom-0.5 -right-0.5 w-4 h-4 rounded-full bg-amber-400 border-2 border-[#131224] flex items-center justify-center text-[8px] font-black text-zinc-950">
                    ★
                  </span>
                ) : (
                  <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-[#131224]" />
                )}
              </div>

              {/* Message Details */}
              <div className="flex-1 overflow-hidden space-y-1">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-bold text-white flex items-center gap-1.5 truncate group-hover:text-[#a042ff] transition-colors">
                    {chat.creator}
                    {chat.verified && (
                      <CheckCircle2 className="w-3.5 h-3.5 text-blue-500 fill-blue-500 text-[#131224]" />
                    )}
                  </h4>
                  <span className={`text-[11px] font-medium shrink-0 ${chat.unreadCount > 0 ? "text-[#a042ff] font-bold" : "text-zinc-500"}`}>
                    {chat.time}
                  </span>
                </div>

                <div className="flex items-center justify-between gap-2">
                  <p className={`text-xs truncate leading-relaxed ${chat.unreadCount > 0 ? "text-zinc-200 font-semibold" : "text-zinc-400"}`}>
                    {chat.lastMessage}
                  </p>

                  {chat.unreadCount > 0 && (
                    <span className="w-5 h-5 rounded-full bg-[#8c1cff] text-[10px] font-black text-white flex items-center justify-center shrink-0 shadow-sm">
                      {chat.unreadCount}
                    </span>
                  )}
                </div>
              </div>
            </Link>
          ))
        )}
      </div>

    </div>
  );
}