"use client";

import React, { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { 
  Heart, 
  Share2, 
  Eye, 
  LineChart, 
  Bell, 
  Send, 
  MoreHorizontal, 
  CheckCircle2, 
  Volume2, 
  Maximize, 
  Play, 
  Pause,
  Download,
  ChevronDown,
  Users,
  ThumbsUp,
  Bookmark,
  Star,
  Flame
} from "lucide-react";

export default function WatchPage() {
  const router = useRouter();
  const [isPlaying, setIsPlaying] = useState(true);
  const [isLiked, setIsLiked] = useState(false);
  const [isDownloadOpen, setIsDownloadOpen] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState<string | null>(null);
  const [inputMessage, setInputMessage] = useState("");
  const [activeTab, setActiveTab] = useState<"upnext" | "comments">("upnext");
  
  const [chatMessages, setChatMessages] = useState([
    { id: 1, user: "Wijaya Abadi", online: true, check: true, avatar: "from-purple-500 to-indigo-500", text: "Duis aute irure dolor in in proident velit esse cillum dolore eu fugiat" },
    { id: 2, user: "Johny Wise", online: false, check: false, avatar: "from-blue-600 to-blue-800", text: "tempor incididunt ut labore" },
    { id: 3, user: "Budi Hakim", online: true, check: true, avatar: "from-orange-500 to-red-500", text: "Duis aute irure dolor in in proident velit esse cillum dolore eu fugiat" },
    { id: 4, user: "Thomas Hope", online: true, check: false, avatar: "from-yellow-600 to-amber-800", text: "velit esse cillum dolore eu fugiat" },
  ]);

  const handleDownload = (quality: string) => {
    setIsDownloadOpen(false);
    setDownloadProgress(quality);
    setTimeout(() => setDownloadProgress(null), 3000);
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim()) return;
    setChatMessages([...chatMessages, {
      id: Date.now(),
      user: "Thomas (You)",
      online: true,
      check: true,
      avatar: "from-amber-600 to-red-600",
      text: inputMessage
    }]);
    setInputMessage("");
  };

  return (
    <>
      {/* 📱 PHONE VIEW (ဖုန်းတွင်သာ သီးသန့် အလုပ်လုပ်မည်) */}
      <div className="md:hidden flex flex-col pb-20 w-full relative z-10">
        
        {/* Sticky Video Player (၄:၃ အချိုးဖြင့် ဖုန်းစခရင်တွင် ပိုမိုကြီးမား ကျယ်ပြန့်စေခြင်း) */}
        <div className="w-full aspect-[4/3] bg-black overflow-hidden relative shadow-2xl z-30 sticky top-0">
          <div 
            className="absolute inset-0 bg-zinc-900 bg-center bg-cover flex items-center justify-center" 
            style={{ backgroundImage: `url('https://images.unsplash.com/photo-1564982755866-9e8c37d8009d?q=80&w=2000&auto=format&fit=crop')` }}
          >
            <div className="w-32 h-32 bg-amber-500/20 blur-[50px] rounded-full translate-x-12 translate-y-10" />
          </div>

          <div className="absolute top-3 left-3 right-3 flex items-center justify-between z-20 pointer-events-auto">
            <button
              onClick={() => window.history.length > 1 ? router.back() : router.push('/')}
              className="w-9 h-9 rounded-full bg-black/50 backdrop-blur-md border border-white/15 flex items-center justify-center text-white active:scale-90 transition-transform cursor-pointer shadow-lg"
            >
              <ChevronDown className="w-5 h-5" />
            </button>
            <span className="text-[10px] font-bold text-zinc-300 bg-black/50 backdrop-blur-md px-2.5 py-1 rounded-full border border-white/10">
              1080p • 60fps
            </span>
          </div>

          {/* 🎛️ Mobile Player Controls (Row 2 တန်းခွဲထားပြီး Seeking Bar ကို အပြည့်ပေးထားခြင်း) */}
          <div className="absolute bottom-0 left-0 right-0 pt-6 pb-2 px-3 bg-gradient-to-t from-black/85 via-black/40 to-transparent flex flex-col gap-2 pointer-events-auto">
            
            {/* Row 1: Play/Pause, Live Badge, Time နှင့် Maximize ခလုတ် */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <button 
                  onClick={() => setIsPlaying(!isPlaying)} 
                  className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white active:scale-95 transition-transform cursor-pointer"
                >
                  {isPlaying ? <Pause className="w-4 h-4 fill-white" /> : <Play className="w-4 h-4 fill-white ml-0.5" />}
                </button>

                <div className="px-2 py-0.5 bg-red-600 rounded text-white font-extrabold text-[9px] uppercase flex items-center gap-1 tracking-wider shrink-0">
                  <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" /> LIVE
                </div>

                <span className="text-[11px] font-mono font-medium text-white/90">17:34 / 59:32</span>
              </div>

              <button 
                className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white active:scale-95 transition-transform cursor-pointer"
                title="Fullscreen"
              >
                <Maximize className="w-4 h-4" />
              </button>
            </div>

            {/* Row 2: ဖုန်းစခရင် အပြည့် လက်မဖြင့် လွတ်လပ်စွာ ဆွဲနိုင်သော Full-width Seeking Bar */}
            <div className="w-full h-3 flex items-center cursor-pointer group/seek relative">
              <div className="w-full h-1 bg-white/30 rounded-full relative overflow-visible">
                <div className="h-full w-1/3 bg-[#8c1cff] rounded-l-full relative shadow-[0_0_8px_#8c1cff]" />
                <div 
                  className="w-3.5 h-3.5 bg-white rounded-full absolute top-1/2 -translate-y-1/2 -ml-1.5 shadow-md scale-100 group-hover/seek:scale-125 transition-transform" 
                  style={{ left: '33%' }} 
                />
              </div>
            </div>

          </div>
        </div>

        {/* Mobile Info & Actions */}
        <div className="flex flex-col px-4 pt-4 pb-2">
          <h1 className="text-xl font-bold leading-snug text-white">
            Oppenheimer Full Movie Recap - The Father of the Atomic Bomb
          </h1>

          <div className="flex items-center gap-2 text-xs text-zinc-400 font-medium mt-2">
            <span>125K views</span>
            <span>•</span>
            <span>2 hours ago</span>
            <span>•</span>
            <span className="text-red-500 font-semibold">Movie Recap</span>
          </div>

          <div className="mt-4 p-3 bg-[#232130] rounded-xl text-xs text-zinc-300 cursor-pointer border border-white/5 flex flex-col gap-1">
            <p className="line-clamp-2">Detailed storyline walkthrough, Christopher Nolan direction notes, and ethical dilemmas of J. Robert Oppenheimer decoded in Burmese.</p>
            <span className="text-red-400 font-bold">...more</span>
          </div>

          <div className="mt-5 flex items-center justify-between">
            <Link href="/channel/minmahar" className="flex items-center gap-3 group cursor-pointer">
              <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-amber-600 to-amber-900 border border-[#1e1c2a] flex items-center justify-center font-bold text-white text-sm">
                M
              </div>
              <div className="flex flex-col">
                <h3 className="text-base font-bold text-white flex items-center gap-1.5 group-hover:text-[#a042ff] transition-colors">
                  Min Mahar
                  <CheckCircle2 className="w-3.5 h-3.5 text-blue-500 fill-blue-500 text-[#131224]" />
                </h3>
                <span className="text-xs text-zinc-400">1.98M subscribers</span>
              </div>
            </Link>
            
            <button className="h-9 px-4 bg-red-600 text-white text-sm font-bold rounded-full transition-transform active:scale-95 shadow-md shadow-red-600/20">
              + Follow
            </button>
          </div>

          <div className="mt-5 flex items-center gap-2.5 overflow-x-auto scrollbar-none pb-2 -mx-4 px-4">
            <button onClick={() => setIsLiked(!isLiked)} className="h-9 px-4 shrink-0 bg-[#232130] rounded-full flex items-center gap-2 text-xs font-bold text-white">
              <ThumbsUp className={`w-4 h-4 ${isLiked ? "fill-white" : ""}`} /> {isLiked ? "47,988" : "47,987"}
            </button>
            <button className="h-9 px-4 shrink-0 bg-[#232130] rounded-full flex items-center gap-2 text-xs font-bold text-white">
              <Bookmark className="w-4 h-4" /> Save
            </button>
            <button className="h-9 px-4 shrink-0 bg-[#232130] rounded-full flex items-center gap-2 text-xs font-bold text-white">
              <Share2 className="w-4 h-4" /> Share
            </button>
            <Link href="/stars" className="h-9 px-4 shrink-0 bg-amber-400 text-zinc-950 rounded-full flex items-center gap-2 text-xs font-black shadow-md shadow-amber-500/20">
              <Star className="w-4 h-4 fill-zinc-950" /> Send Star
            </Link>
          </div>

          <style>{`
            @keyframes commentMarquee {
              0% { transform: translateX(100%); }
              100% { transform: translateX(-100%); }
            }
            .animate-comment-ticker {
              display: inline-block;
              white-space: nowrap;
              animation: commentMarquee 15s linear infinite;
            }
            .animate-comment-ticker:hover {
              animation-play-state: paused;
            }
          `}</style>

          {/* Sticky Mobile Tabs Bar */}
          <div className="sticky top-[75vw] z-20 bg-[#131224] -mx-4 px-4 pt-3 pb-2.5 border-b border-white/10 flex items-center justify-between gap-3">
            <div className="flex items-center gap-5 shrink-0">
              <button
                onClick={() => setActiveTab("upnext")}
                className={`text-sm font-bold transition-all relative pb-1 cursor-pointer ${
                  activeTab === "upnext" ? "text-white" : "text-zinc-400 hover:text-zinc-200"
                }`}
              >
                Up Next
                {activeTab === "upnext" && (
                  <span className="absolute -bottom-2.5 left-0 right-0 h-0.5 bg-red-600 rounded-full" />
                )}
              </button>

              <button
                onClick={() => setActiveTab("comments")}
                className={`text-sm font-bold transition-all relative pb-1 cursor-pointer flex items-center gap-1.5 ${
                  activeTab === "comments" ? "text-white" : "text-zinc-400 hover:text-zinc-200"
                }`}
              >
                Comments ({chatMessages.length})
                {activeTab === "comments" && (
                  <span className="absolute -bottom-2.5 left-0 right-0 h-0.5 bg-red-600 rounded-full" />
                )}
              </button>
            </div>

            <div 
              onClick={() => setActiveTab("comments")}
              className="flex-1 max-w-[185px] sm:max-w-[260px] h-7 bg-[#1c1a27] hover:bg-[#252236] border border-white/10 rounded-full px-2.5 flex items-center gap-1.5 overflow-hidden cursor-pointer transition-all active:scale-95 group shadow-sm"
              title="Click to view all comments"
            >
              <Flame className="w-3.5 h-3.5 fill-red-500 text-red-500 shrink-0" />
              <div className="overflow-hidden whitespace-nowrap relative w-full flex items-center">
                <div className="animate-comment-ticker text-[11px] text-zinc-300">
                  <span className="font-bold text-white mr-1">{chatMessages[0]?.user}:</span>
                  <span className="text-zinc-400">"{chatMessages[0]?.text}"</span>
                </div>
              </div>
            </div>
          </div>

          {/* Mobile Tab Content */}
          <div className="mt-4 space-y-3">
            {activeTab === "upnext" ? (
              <div className="space-y-4 pt-1">
                {[
                  { id: 2, title: "Myanmar Digital Banking Reform & Currency Value Analysis 2026", author: "Fintech MM", duration: "22:15", time: "5 hours ago", views: "48K views", bg: "from-blue-950/60 to-zinc-950" },
                  { id: 3, title: "Solo Leveling: Ragnarok Episodes 1 to 15 (Motion Comic Recap)", author: "Comic Hub", duration: "29:40", time: "1 day ago", views: "89K views", bg: "from-emerald-950/60 to-zinc-950" },
                  { id: 4, title: "The Art of War by Sun Tzu (Full Audiobook with Myanmar Explanation)", author: "Book Tube MM", duration: "45:10", time: "3 days ago", views: "61K views", bg: "from-purple-950/60 to-zinc-950" },
                ].map((v) => (
                  <Link
                    key={v.id}
                    href={`/watch/${v.id}`}
                    className="flex gap-3 py-1 rounded-xl transition-colors group cursor-pointer active:opacity-75"
                  >
                    <div className={`relative w-40 sm:w-48 aspect-[16/9] rounded-xl bg-gradient-to-tr ${v.bg} border border-white/10 overflow-hidden shrink-0 flex items-center justify-center shadow-md`}>
                      <span className="absolute bottom-1.5 right-1.5 bg-black/85 font-mono text-[10px] font-bold text-zinc-200 px-1.5 py-0.5 rounded backdrop-blur-sm">
                        {v.duration}
                      </span>
                      <div className="w-8 h-8 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-opacity">
                        <Play className="w-4 h-4 fill-white ml-0.5" />
                      </div>
                    </div>

                    <div className="flex-1 flex flex-col justify-start py-0.5 overflow-hidden">
                      <h4 className="text-xs sm:text-sm font-bold text-white group-hover:text-[#a042ff] transition-colors line-clamp-2 leading-snug">
                        {v.title}
                      </h4>
                      <p className="text-[11px] text-zinc-400 mt-1 font-medium truncate">{v.author}</p>
                      <p className="text-[10px] text-zinc-500 mt-0.5">{v.views} • {v.time}</p>
                    </div>
                  </Link>
                ))}
              </div>
            ) : (
              <div className="space-y-4 pb-16">
                <div className="flex items-center gap-1.5 text-xs font-black text-amber-400 uppercase tracking-wider pt-1">
                  <span>★ STAR SUPPORTER SHOUTOUTS</span>
                </div>

                <div className="space-y-3">
                  <div className="p-4 rounded-2xl bg-[#181622] border border-amber-500/60 shadow-[0_0_15px_rgba(245,158,11,0.08)] space-y-2.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-full bg-amber-400 text-zinc-950 font-black text-xs flex items-center justify-center shrink-0">
                          KP
                        </div>
                        <div>
                          <h4 className="text-xs font-bold text-amber-200">Ko Thet Paing</h4>
                          <span className="text-[10px] text-zinc-400">1 hour ago</span>
                        </div>
                      </div>
                      <span className="px-2.5 py-0.5 rounded-full border border-amber-500/50 bg-amber-500/10 text-amber-400 text-[11px] font-black flex items-center gap-1">
                        ★ ★ 500 Stars
                      </span>
                    </div>
                    <p className="text-xs text-zinc-200 leading-relaxed font-medium">
                      ★ Sent 500 Stars! Burma Frontier does the most courageous reporting on the ground. Thank you tobm for building a fair creator compensation model that works inside Myanmar without bank restrictions!
                    </p>
                  </div>
                </div>

                {/* Fixed Bottom Comment Bar */}
                <div className="fixed bottom-0 left-0 right-0 z-50 bg-[#131224] border-t border-white/10 px-4 py-2.5 flex items-center gap-3">
                  <Link 
                    href="/stars"
                    className="w-10 h-10 rounded-full bg-[#242132] border border-amber-500/40 flex items-center justify-center text-amber-400 hover:scale-105 active:scale-95 transition-transform shrink-0"
                  >
                    <Star className="w-4 h-4 fill-amber-400" />
                  </Link>

                  <form onSubmit={handleSendMessage} className="flex-1 flex items-center relative">
                    <input 
                      type="text" 
                      value={inputMessage}
                      onChange={(e) => setInputMessage(e.target.value)}
                      placeholder="Add a comment..." 
                      className="w-full h-10 rounded-full bg-[#201e2c] border border-white/10 pl-4 pr-3 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-red-500"
                    />
                  </form>

                  <button 
                    onClick={handleSendMessage}
                    className="w-10 h-10 rounded-full bg-red-600 hover:bg-red-500 flex items-center justify-center text-white shrink-0 active:scale-95 transition-transform cursor-pointer shadow-md shadow-red-600/30"
                  >
                    <Send className="w-4 h-4 fill-white ml-0.5" />
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* 💻 PC VIEW (သင်၏ မူလ Code အတိုင်း ၁၀၀% မူလအတိုင်း ထားရှိသည်) */}
      <div className="hidden md:grid px-4 sm:px-8 pb-12 pt-2 w-full grid-cols-1 lg:grid-cols-12 gap-6 items-start relative z-10 max-w-[1700px] mx-auto">
      
      {/* ============ LEFT COLUMN: VIDEO + METADATA ============ */}
      <div className="lg:col-span-8 flex flex-col">
        
        {/* 🎬 Video Player */}
        <div className="w-full aspect-[16/9] bg-black rounded-3xl overflow-hidden relative shadow-2xl group border border-white/5">
          <div 
            className="absolute inset-0 bg-zinc-900 bg-center bg-cover flex items-center justify-center" 
            style={{ backgroundImage: `url('https://images.unsplash.com/photo-1564982755866-9e8c37d8009d?q=80&w=2000&auto=format&fit=crop')` }}
          >
            <div className="w-32 h-32 bg-amber-500/20 blur-[50px] rounded-full translate-x-12 translate-y-10" />
          </div>
          
          <div className="absolute bottom-5 left-5 right-5 p-4 rounded-2xl bg-black/40 backdrop-blur-md border border-white/10 flex items-center justify-between gap-4">
            <div className="flex items-center gap-4 w-full">
              <div className="px-3 py-1 bg-red-600 rounded-lg text-white font-extrabold text-[10px] uppercase flex items-center gap-1.5 tracking-wider">
                <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" /> LIVE
              </div>

              <button 
                onClick={() => setIsPlaying(!isPlaying)}
                className="text-white hover:scale-110 transition-transform cursor-pointer"
              >
                {isPlaying ? <Pause className="w-4 h-4 fill-white" /> : <Play className="w-4 h-4 fill-white" />}
              </button>

              <div className="flex-1 h-1 bg-white/20 rounded-full cursor-pointer relative overflow-visible flex items-center">
                <div className="h-full w-1/3 bg-[#8c1cff] rounded-l-full relative shadow-[0_0_10px_#8c1cff]" />
                <div className="w-3 h-3 bg-white rounded-full absolute shadow-md cursor-grab" style={{ left: '33%' }} />
              </div>
              
              <span className="text-xs font-mono font-medium text-white px-2">17:34 / 59:32</span>

              <button className="text-white hover:text-red-400 transition-colors"><Volume2 className="w-4 h-4" /></button>
              <button className="text-white hover:text-red-400 transition-colors"><Maximize className="w-4 h-4" /></button>
            </div>
          </div>
        </div>

        {/* Creator Row & Info */}
        <div className="mt-4 flex flex-col md:flex-row justify-between items-start gap-6">
          
          <div className="flex-1 max-w-2xl">
            
            {/* 🔗 Creator Profile Link */}
            <Link href="/channel/minmahar" className="flex items-center gap-3.5 group cursor-pointer w-max">
              <div className="relative group-hover:scale-105 transition-transform">
                <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-amber-600 to-amber-900 border border-[#1e1c2a] font-bold text-white flex items-center justify-center">
                  M
                </div>
                <div className="absolute -bottom-1 -right-1 bg-blue-500 rounded-full w-4 h-4 border-2 border-[#14121d] flex items-center justify-center">
                  <CheckCircle2 className="w-2.5 h-2.5 text-white" />
                </div>
              </div>
              <div className="flex flex-col">
                <h3 className="text-lg font-bold text-white flex items-center gap-2 group-hover:text-[#a042ff] transition-colors">
                  Min Mahar
                </h3>
                <span className="text-sm font-medium text-zinc-400">1,980,893 subscribers</span>
              </div>
            </Link>

            <h1 className="mt-5 text-2xl sm:text-3xl font-black tracking-tight leading-snug text-white">
              Oppenheimer Full Movie Recap - The Father of the Atomic Bomb
            </h1>

            <div className="mt-5 space-y-4 text-base font-normal text-zinc-200 leading-relaxed pr-4">
              <p>Detailed storyline walkthrough, Christopher Nolan direction notes, and ethical dilemmas of J. Robert Oppenheimer decoded in Burmese.</p>
            </div>
          </div>

          {/* Action Buttons Row */}
          <div className="flex flex-col gap-6 md:w-72 shrink-0 md:pt-2">
            
            <div className="flex items-center gap-2.5">
              {/* DOWNLOAD BUTTON */}
              <div className="relative flex-1">
                <button 
                  onClick={() => setIsDownloadOpen(!isDownloadOpen)}
                  title="Download video for offline"
                  className="w-full h-11 bg-[#1c1a27] hover:bg-[#232031] border border-white/5 transition-colors rounded-xl flex items-center justify-center gap-2 text-sm font-bold text-zinc-200 cursor-pointer"
                >
                  <Download className="w-4 h-4 text-red-500" />
                  <span>{downloadProgress ? `DL (${downloadProgress})` : "DL"}</span>
                  <ChevronDown className="w-3.5 h-3.5 text-zinc-400" />
                </button>

                {isDownloadOpen && (
                  <>
                    <div onClick={() => setIsDownloadOpen(false)} className="fixed inset-0 z-40" />
                    <div className="absolute left-0 top-12 w-44 bg-[#181822] border border-white/10 rounded-2xl p-1.5 shadow-2xl z-50 animate-in fade-in zoom-in-95 space-y-0.5">
                      <p className="text-[10px] font-bold text-zinc-400 px-3 py-1 uppercase tracking-wider">Select Quality</p>
                      {[
                        { res: "1080p (FHD)", size: "480 MB" },
                        { res: "720p (HD)", size: "220 MB" },
                        { res: "360p (Saver)", size: "95 MB" },
                      ].map((q) => (
                        <button
                          key={q.res}
                          onClick={() => handleDownload(q.res.split(" ")[0])}
                          className="w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium text-zinc-300 hover:bg-zinc-800 hover:text-white transition-colors cursor-pointer"
                        >
                          <span>{q.res}</span>
                          <span className="text-[10px] text-zinc-500">{q.size}</span>
                        </button>
                      ))}
                    </div>
                  </>
                )}
              </div>

              <button className="flex-1 h-11 bg-[#1c1a27] hover:bg-[#232031] border border-white/5 transition-colors rounded-xl flex items-center justify-center gap-2 text-sm font-bold text-zinc-200 cursor-pointer">
                <Share2 className="w-4 h-4 text-zinc-400" /> Share
              </button>

              <button 
                onClick={() => setIsLiked(!isLiked)}
                className={`flex-1 h-11 transition-colors rounded-xl flex items-center justify-center gap-2 text-sm font-bold cursor-pointer ${
                  isLiked ? "bg-[#8c1cff] text-white shadow-[0_5px_15px_rgba(140,28,255,0.35)]" : "bg-[#1c1a27] text-zinc-200 hover:bg-[#232031] border border-white/5"
                }`}
              >
                <Heart className={`w-4 h-4 ${isLiked ? "fill-white text-white" : "text-zinc-400"}`} /> Liked
              </button>
            </div>

            {/* Metrics */}
            <div className="space-y-3.5 text-base font-semibold text-zinc-100 pt-1">
              <div className="flex items-center gap-3"><Eye className="w-5 h-5 text-zinc-400" /> 125,908 views</div>
              <div className="flex items-center gap-3"><Heart className="w-5 h-5 fill-red-500 text-red-500" /> 47,987 likes</div>
              <div className="flex items-center gap-3"><LineChart className="w-5 h-5 text-zinc-400" /> 1,938,394 streaming</div>
              <div className="flex items-center gap-3"><Bell className="w-5 h-5 text-zinc-400" /> Start 2 hours ago</div>
            </div>
          </div>
        </div>
      </div>

      {/* ============ RIGHT COLUMN: CHAT + RELATED ============ */}
      <div className="lg:col-span-4 flex flex-col gap-8 w-full max-w-[420px] mx-auto xl:mx-0">
        
        {/* Live Chat Pane */}
        <div className="w-full bg-[#181628] rounded-3xl border border-white/5 flex flex-col p-6 shadow-xl relative">
          <div className="flex items-center justify-between mb-6 pb-2">
            <h3 className="font-bold text-base text-white">Live Chat</h3>
            <span className="flex items-center gap-2 text-[11px] font-bold text-[#797a8e]">
              <Users className="w-4 h-4" /> 15,986 people
            </span>
          </div>

          <div className="space-y-6 max-h-[300px] overflow-y-auto pr-2 scrollbar-none flex-1 mb-4">
            {chatMessages.map((user) => (
              <div key={user.id} className="flex gap-4">
                <div className="relative shrink-0">
                  <div className={`w-9 h-9 rounded-full bg-gradient-to-tr ${user.avatar} font-bold text-xs flex items-center justify-center text-white border border-[#1e1c2a]`}>
                    {user.user.charAt(0)}
                  </div>
                  {user.check && (
                    <div className="absolute -bottom-1 -right-1 bg-blue-500 w-3.5 h-3.5 rounded-full flex items-center justify-center border-2 border-[#1c1a27]">
                      <CheckCircle2 className="w-2.5 h-2.5 text-white" />
                    </div>
                  )}
                </div>
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-sm font-bold text-white">
                    {user.user} 
                    {user.online ? <div className="w-2 h-2 bg-[#1bc285] rounded-full" /> : <div className="w-2 h-2 bg-[#fc5b69] rounded-full" />}
                  </div>
                  <p className="text-sm leading-relaxed text-zinc-100">{user.text}</p>
                </div>
              </div>
            ))}
          </div>

          <form onSubmit={handleSendMessage} className="relative flex items-center h-12 w-full mt-2">
            <input 
              type="text" 
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              placeholder="Write your message..." 
              className="w-full h-full rounded-2xl bg-[#14121d] border border-transparent pl-12 pr-12 text-sm font-medium text-white placeholder-zinc-400 focus:outline-none focus:border-[#8c1cff]/50"
            />
            <MoreHorizontal className="absolute left-4 w-4 h-4 text-zinc-500" />
            <button type="submit" className="absolute right-1 w-10 h-10 rounded-xl bg-[#8c1cff] flex items-center justify-center shadow-lg transition-transform hover:scale-105 hover:bg-[#7818e3] cursor-pointer">
              <Send className="w-3.5 h-3.5 text-white mr-0.5" />
            </button>
          </form>
        </div>

        {/* Related Videos */}
        <div className="space-y-4 w-full">
          <h3 className="font-bold text-base text-white pl-2">Related Videos</h3>
          <div className="space-y-4">
            {[
              { id: 2, title: "Prepare for your first skateboard jump", author: "Min Mahar", handle: "minmahar", views: "125,908 views", time: "2 days ago", bg: "from-zinc-500 to-slate-700" },
              { id: 3, title: "Tips to playing skateboard on the ramp", author: "Fintech MM", handle: "fintech_mm", views: "125,908 views", time: "2 days ago", bg: "from-amber-600 to-amber-900" }
            ].map((v, i) => (
              <div key={i} className="flex gap-4 p-1 hover:bg-white/5 transition-colors rounded-xl cursor-pointer group">
                <Link href={`/watch/${v.id}`} className={`w-32 h-[76px] rounded-[18px] bg-gradient-to-tr ${v.bg} border border-white/5 flex items-center justify-center shrink-0`} />
                
                <div className="flex flex-col py-0.5 pr-2 flex-1">
                  <Link href={`/watch/${v.id}`}>
                    <h4 className="text-base font-bold text-white group-hover:text-[#a042ff] transition-colors leading-snug line-clamp-2">
                      {v.title}
                    </h4>
                  </Link>

                  <Link href={`/channel/${v.handle}`} className="text-sm font-semibold text-zinc-200 hover:text-white mt-1.5 transition-colors w-max">
                    {v.author}
                  </Link>
                  <p className="text-xs sm:text-sm text-zinc-400 mt-1 font-medium">{v.views} • {v.time}</p>
                </div>
              </div>
            ))}
          </div>
          <button className="w-full h-11 bg-[#8c1cff] hover:bg-[#7a14e6] text-white rounded-[16px] text-xs font-bold transition-all shadow-[0_5px_15px_rgba(140,28,255,0.3)] mt-2 cursor-pointer">
            See All related videos (32)
          </button>
        </div>

      </div>
    </div>
    </>
  );
}