"use client";

import React, { useState } from "react";
import Link from "next/link";
import { 
  Users, 
  Sparkles, 
  Play, 
  Star, 
  Eye, 
  CheckCircle2, 
  Radio, 
  SlidersHorizontal,
  Bell
} from "lucide-react";

// Mock Subscribed Creators (ထိပ်ဆုံး Bar အတွက်)
const subscribedCreators = [
  { id: 1, name: "Min Mahar", handle: "minmahar", avatar: "from-amber-600 to-amber-900", hasNew: true, isLive: false },
  { id: 2, name: "Fintech MM", handle: "fintech_mm", avatar: "from-blue-600 to-blue-800", hasNew: true, isLive: true },
  { id: 3, name: "Comic Hub", handle: "comic_hub", avatar: "from-emerald-600 to-teal-800", hasNew: false, isLive: false },
  { id: 4, name: "Book Tube MM", handle: "book_tube", avatar: "from-purple-600 to-indigo-800", hasNew: true, isLive: false },
  { id: 5, name: "Khit Tech", handle: "khit_tech", avatar: "from-red-600 to-rose-900", hasNew: false, isLive: false },
  { id: 6, name: "Gamer MM", handle: "gamer_mm", avatar: "from-orange-600 to-amber-800", hasNew: true, isLive: false },
];

// Mock Subscription Feed Videos
const subscriptionVideos = [
  {
    id: 1,
    title: "Oppenheimer Full Movie Recap - The Father of the Atomic Bomb",
    creator: "Min Mahar",
    handle: "minmahar",
    avatar: "from-amber-600 to-amber-900",
    verified: true,
    views: "125,908",
    time: "2 hours ago",
    duration: "38:20",
    category: "Movie Recap",
    stars: 3850,
    thumbnailBg: "from-amber-950/60 via-zinc-900 to-zinc-950",
    isLive: false,
    unwatched: true,
  },
  {
    id: 2,
    title: "Myanmar Digital Banking Reform & Currency Value Analysis 2026",
    creator: "Fintech MM",
    handle: "fintech_mm",
    avatar: "from-blue-600 to-blue-800",
    verified: true,
    views: "48,900",
    time: "Streaming Now",
    duration: "Live",
    category: "News & Politics",
    stars: 2450,
    thumbnailBg: "from-blue-950/60 via-zinc-900 to-zinc-950",
    isLive: true,
    unwatched: true,
  },
  {
    id: 4,
    title: "The Art of War by Sun Tzu (Full Audiobook with Myanmar Explanation)",
    creator: "Book Tube MM",
    handle: "book_tube",
    avatar: "from-purple-600 to-indigo-800",
    verified: true,
    views: "61,800",
    time: "1 day ago",
    duration: "45:10",
    category: "Audiobooks",
    stars: 2850,
    thumbnailBg: "from-purple-950/60 via-zinc-900 to-zinc-950",
    isLive: false,
    unwatched: false,
  },
  {
    id: 6,
    title: "Black Myth Wukong Boss Fight Guide & Hidden Secrets",
    creator: "Gamer MM",
    handle: "gamer_mm",
    avatar: "from-orange-600 to-amber-800",
    verified: false,
    views: "115,200",
    time: "2 days ago",
    duration: "42:15",
    category: "Gaming & Live",
    stars: 5200,
    thumbnailBg: "from-orange-950/60 via-zinc-900 to-zinc-950",
    isLive: false,
    unwatched: false,
  },
];

export default function SubscriptionsPage() {
  const [filter, setFilter] = useState<"all" | "unwatched" | "live">("all");
  const [selectedCreator, setSelectedCreator] = useState<string | null>(null);

  const filteredVideos = subscriptionVideos.filter((v) => {
    const matchesCreator = selectedCreator ? v.handle === selectedCreator : true;
    if (filter === "live") return matchesCreator && v.isLive;
    if (filter === "unwatched") return matchesCreator && v.unwatched;
    return matchesCreator;
  });

  return (
    <div className="px-4 sm:px-8 pb-16 pt-20 md:pt-4 max-w-[1700px] mx-auto space-y-8 relative z-10 animate-in fade-in duration-300">
      
      {/* ================= ၁။ FOLLOWED CREATORS STORIES BAR ================= */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-xs font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-2">
            <Users className="w-4 h-4 text-red-500" />
            <span>Subscribed Creators ({subscribedCreators.length})</span>
          </h2>
          <Link
            href="/channel/minmahar"
            className="text-xs font-bold text-zinc-400 hover:text-white transition-colors"
          >
            Manage
          </Link>
        </div>

        {/* Horizontal Creator Avatars Carousel */}
        <div className="flex items-center gap-4 overflow-x-auto pb-2 scrollbar-none pt-1">
          {/* All Creators Reset Button */}
          <button
            onClick={() => setSelectedCreator(null)}
            className={`flex flex-col items-center gap-2 shrink-0 cursor-pointer group`}
          >
            <div className={`w-14 h-14 rounded-full border-2 flex items-center justify-center transition-all ${
              selectedCreator === null 
                ? "border-red-600 bg-red-600/10 text-white shadow-[0_0_15px_rgba(220,38,38,0.3)]" 
                : "border-white/10 bg-[#1c1a27] text-zinc-400 group-hover:border-zinc-600"
            }`}>
              <Sparkles className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-bold text-zinc-300">All</span>
          </button>

          {/* Creators List */}
          {subscribedCreators.map((creator) => {
            const isSelected = selectedCreator === creator.handle;
            return (
              <button
                key={creator.id}
                onClick={() => setSelectedCreator(isSelected ? null : creator.handle)}
                className="flex flex-col items-center gap-2 shrink-0 cursor-pointer group"
              >
                <div className="relative">
                  {/* Avatar with Ring (Live or New Upload indicator) */}
                  <div className={`w-14 h-14 rounded-full bg-gradient-to-tr ${creator.avatar} flex items-center justify-center font-bold text-white text-sm border-2 transition-all group-hover:scale-105 ${
                    isSelected 
                      ? "border-[#8c1cff] shadow-[0_0_15px_rgba(140,28,255,0.5)]" 
                      : creator.isLive 
                        ? "border-red-500 shadow-[0_0_15px_rgba(239,68,68,0.5)] animate-pulse" 
                        : creator.hasNew 
                          ? "border-[#8c1cff]" 
                          : "border-white/10"
                  }`}>
                    {creator.name.charAt(0)}
                  </div>

                  {/* Live Badge */}
                  {creator.isLive && (
                    <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 px-1.5 py-0.2 rounded-full bg-red-600 text-[9px] font-black uppercase text-white shadow-md">
                      Live
                    </span>
                  )}

                  {/* New Upload Dot */}
                  {!creator.isLive && creator.hasNew && (
                    <span className="absolute top-0 right-0 w-3.5 h-3.5 rounded-full bg-[#fc5b69] border-2 border-[#14121d]" />
                  )}
                </div>

                <span className={`text-[11px] font-semibold truncate max-w-[70px] ${
                  isSelected ? "text-white font-bold" : "text-zinc-400 group-hover:text-zinc-200"
                }`}>
                  {creator.name}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* ================= ၂။ FILTER TABS & FEED HEADER ================= */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-t border-white/5 pt-6">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2.5">
            <span>{selectedCreator ? `@${selectedCreator}'s Feed` : "Subscriptions Feed"}</span>
          </h1>
          <p className="text-xs text-[#797a8e] mt-1">
            Latest uploads and streams exclusively from channels you follow
          </p>
        </div>

        {/* Quick Filter Pills */}
        <div className="flex items-center gap-2 self-start sm:self-auto">
          {[
            { id: "all", label: "All" },
            { id: "unwatched", label: "Unwatched" },
            { id: "live", label: "Live Now" },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilter(tab.id as typeof filter)}
              className={`px-4 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                filter === tab.id
                  ? "bg-[#fc5b69] text-white shadow-[0_4px_14px_rgba(252,91,105,0.3)]"
                  : "bg-[#1c1a27] border border-white/5 text-zinc-400 hover:text-white hover:bg-zinc-800"
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* ================= ၃။ SUBSCRIPTION VIDEOS GRID ================= */}
      {filteredVideos.length === 0 ? (
        <div className="py-20 text-center rounded-3xl bg-[#1c1a27]/50 border border-white/5 space-y-2">
          <Users className="w-10 h-10 text-zinc-600 mx-auto" />
          <h3 className="text-base font-bold text-white">No videos found</h3>
          <p className="text-xs text-[#797a8e]">
            There are no uploads matching your current filter.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredVideos.map((video) => (
            <div
              key={video.id}
              className="group cursor-pointer flex flex-col gap-2.5"
            >
              {/* Thumbnail (Link to Watch Page) */}
              <Link 
                href={`/watch/${video.id}`}
                className={`relative w-full aspect-[16/9] rounded-xl bg-gradient-to-tr ${video.thumbnailBg} border border-zinc-800/80 overflow-hidden flex items-center justify-center cursor-pointer`}
              >
                {/* Live or Duration */}
                {video.isLive ? (
                  <div className="absolute top-3 left-3 px-2.5 py-0.5 rounded-lg bg-red-600 text-white font-black text-[10px] uppercase flex items-center gap-1 tracking-wider shadow-md">
                    <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" /> LIVE
                  </div>
                ) : (
                  <span className="absolute bottom-3 right-3 bg-black/85 font-mono text-[11px] font-bold text-zinc-200 px-2 py-0.5 rounded-md backdrop-blur-sm">
                    {video.duration}
                  </span>
                )}

                {/* Stars Badge */}
                <div className="absolute top-3 right-3 px-2 py-0.5 rounded-full bg-amber-500/20 backdrop-blur-md border border-amber-500/30 text-amber-300 text-[10px] font-black flex items-center gap-1 shadow-sm">
                  <Star className="w-3 h-3 fill-amber-400" />
                  <span>+{video.stars.toLocaleString()}</span>
                </div>

                {/* Hover Play Button */}
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="w-12 h-12 rounded-full bg-[#8c1cff] text-white flex items-center justify-center shadow-lg shadow-[#8c1cff]/40 transform group-hover:scale-110 transition-transform">
                    <Play className="w-5 h-5 fill-white ml-0.5" />
                  </div>
                </div>
              </Link>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">

                <div className="flex-1 overflow-hidden space-y-1">
                  {/* Title (Link to Watch) */}
                  <Link href={`/watch/${video.id}`}>
                    <h3 className="text-sm font-bold text-white group-hover:text-[#fc5b69] transition-colors line-clamp-2 leading-snug cursor-pointer">
                      {video.title}
                    </h3>
                  </Link>

                  {/* Creator Name (Link to Channel) */}
                  <div className="flex items-center gap-1.5 text-xs text-zinc-400">
                    <Link 
                      href={`/channel/${video.handle}`}
                      className="font-semibold text-zinc-300 hover:text-white transition-colors"
                    >
                      {video.creator}
                    </Link>
                    {video.verified && (
                      <CheckCircle2 className="w-3.5 h-3.5 text-blue-500 fill-blue-500 text-[#1c1a27]" />
                    )}
                  </div>

                  <div className="flex items-center gap-2 text-[11px] text-[#797a8e] font-medium pt-0.5">
                    <span>{video.views} views</span>
                    <span>•</span>
                    <span className="text-[#fc5b69] font-bold">{video.time}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

    </div>
  );
}